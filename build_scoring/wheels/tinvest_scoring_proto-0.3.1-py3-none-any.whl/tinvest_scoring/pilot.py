"""Аудит доказательного пакета пилотного эмитента.

Модуль намеренно не вызывает ``score_universe``: пилот проверяет происхождение
данных и контракты до допуска эмитента к секторному скорингу.
"""
from __future__ import annotations

import csv
import hashlib
from dataclasses import dataclass
from pathlib import Path

from .models import CrosscheckRow, CrosscheckStatus, DividendRecord, FundamentalRecord


@dataclass(frozen=True)
class SourceDocument:
    document_id: str
    document_type: str
    fiscal_year: str
    publication_date: str
    version_status: str
    source_url: str
    local_path: str
    bytes: int | None
    sha256: str
    archive_status: str
    source_tier: str
    source_verified: bool
    notes: str


REGISTRY_COLUMNS = {
    "document_id", "document_type", "fiscal_year", "publication_date",
    "version_status", "source_url", "local_path", "bytes", "sha256",
    "archive_status", "source_tier", "source_verified", "notes",
}


def load_source_registry(path: Path) -> list[SourceDocument]:
    """Загрузить реестр без сетевых запросов и проверить структуру строк."""
    if not path.exists():
        raise ValueError(f"Реестр источников не найден: {path}")
    with path.open("r", encoding="utf-8-sig", newline="") as fh:
        reader = csv.DictReader(fh)
        missing = REGISTRY_COLUMNS - set(reader.fieldnames or [])
        if missing:
            raise ValueError(
                f"{path}: отсутствуют столбцы: {', '.join(sorted(missing))}"
            )
        rows = []
        seen = set()
        for number, raw in enumerate(reader, start=2):
            row = {key: (value or "").strip() for key, value in raw.items()}
            document_id = row["document_id"]
            if not document_id or document_id in seen:
                raise ValueError(
                    f"{path}:{number}: пустой или повторный document_id {document_id!r}"
                )
            seen.add(document_id)
            if row["archive_status"] not in {"archived", "remote-only"}:
                raise ValueError(
                    f"{path}:{number}: archive_status должен быть archived/remote-only"
                )
            if row["source_tier"] not in {"A", "B", "C"}:
                raise ValueError(f"{path}:{number}: неверный source_tier")
            rows.append(SourceDocument(
                document_id=document_id,
                document_type=row["document_type"], fiscal_year=row["fiscal_year"],
                publication_date=row["publication_date"],
                version_status=row["version_status"], source_url=row["source_url"],
                local_path=row["local_path"],
                bytes=int(row["bytes"]) if row["bytes"] else None,
                sha256=row["sha256"].upper(), archive_status=row["archive_status"],
                source_tier=row["source_tier"],
                source_verified=row["source_verified"].casefold() == "true",
                notes=row["notes"],
            ))
    return rows


def validate_source_archive(
    registry_path: Path, documents: list[SourceDocument]
) -> list[str]:
    """Сверить размер, SHA-256 и сигнатуру каждого архивного документа."""
    errors: list[str] = []
    base = registry_path.parent
    for item in documents:
        if not item.source_url:
            errors.append(f"{item.document_id}: отсутствует официальный URL")
        if item.archive_status == "remote-only":
            if item.local_path or item.sha256 or item.bytes is not None:
                errors.append(
                    f"{item.document_id}: remote-only не должен имитировать локальный архив"
                )
            continue
        if not item.local_path or not item.sha256 or item.bytes is None:
            errors.append(f"{item.document_id}: архивная запись неполна")
            continue
        local = (base / item.local_path).resolve()
        try:
            local.relative_to(base.resolve())
        except ValueError:
            errors.append(f"{item.document_id}: local_path выходит за каталог пилота")
            continue
        if not local.is_file():
            errors.append(f"{item.document_id}: файл не найден: {local}")
            continue
        payload = local.read_bytes()
        if len(payload) != item.bytes:
            errors.append(
                f"{item.document_id}: размер {len(payload)} вместо {item.bytes}"
            )
        actual = hashlib.sha256(payload).hexdigest().upper()
        if actual != item.sha256:
            errors.append(f"{item.document_id}: SHA-256 не совпадает")
        suffix = local.suffix.casefold()
        if suffix == ".pdf" and not payload.startswith(b"%PDF-"):
            errors.append(f"{item.document_id}: расширение PDF без сигнатуры PDF")
        if suffix == ".xlsx" and not payload.startswith(b"PK"):
            errors.append(f"{item.document_id}: расширение XLSX без ZIP-сигнатуры")
    return errors


def write_pilot_audit_markdown(
    path: Path,
    *,
    documents: list[SourceDocument],
    archive_errors: list[str],
    fundamentals: list[FundamentalRecord],
    dividends: list[DividendRecord],
    crosscheck_rows: list[CrosscheckRow],
) -> Path:
    secids = sorted({row.secid for row in fundamentals})
    secid = secids[0] if len(secids) == 1 else "эмитента"
    years = sorted({row.fiscal_year for row in fundamentals})
    required_missing_by_year = {
        row.fiscal_year: [
            name for name in (
                "revenue", "ebitda", "net_income", "equity",
                "interest_debt", "cash",
            ) if getattr(row, name) is None
        ]
        for row in fundamentals
    }
    fundamental_by_year = {row.fiscal_year: row for row in fundamentals}
    non_cash_fields = (
        "revenue", "ebitda", "net_income", "equity", "interest_debt",
    )
    non_cash_missing = [
        f"{year}:{field}"
        for year, row in sorted(fundamental_by_year.items())
        for field in non_cash_fields
        if getattr(row, field) is None
    ]
    cash_missing_years = sorted(
        year for year, row in fundamental_by_year.items() if row.cash is None
    )
    fcf_missing_years = sorted(
        year for year, row in fundamental_by_year.items() if row.fcf is None
    )
    non_ifrs_years = sorted(
        year
        for year, row in fundamental_by_year.items()
        if row.standard.upper() not in {"IFRS", "МСФО"}
    )
    fcf_absence_summary = (
        "Годы без FCF: "
        f"{', '.join(map(str, fcf_missing_years))}; "
        "по MD-003 каждый такой год получает 0 баллов без исключения эмитента."
        if fcf_missing_years
        else "Все годы FCF подтверждены."
    )
    expected_dividend_years = set(range(2021, 2026))
    known_dividend_years = {row.payment_year for row in dividends}
    missing_dividend_years = sorted(expected_dividend_years - known_dividend_years)
    status_counts = {
        status: sum(row.status == status for row in crosscheck_rows)
        for status in CrosscheckStatus
    }
    archived = sum(row.archive_status == "archived" for row in documents)
    remote = sum(row.archive_status == "remote-only" for row in documents)
    lines = [
        f"# Аудит пилота {secid} — этап C", "",
        "> Не инвестиционная рекомендация. Пилот проверяет данные и не выбирает акции.",
        "", "## Технический итог", "",
        f"- Реестр: {len(documents)} документов; локально архивировано {archived}; remote-only {remote}.",
        f"- Ошибки архива: {len(archive_errors)}.",
        f"- Фундаментальные строки: {len(fundamentals)}; годы: {', '.join(map(str, years)) or 'нет'}.",
        f"- Подтверждения выплаты/невыплаты дивидендов в строгом контракте: {len(dividends)}.",
        f"- Непокрытые календарные годы дивидендов: {', '.join(map(str, missing_dividend_years)) or 'нет'}.",
        f"- Кросс-чек: совпал {status_counts[CrosscheckStatus.MATCHED]}, расходится {status_counts[CrosscheckStatus.MISMATCHED]}, не проверен {status_counts[CrosscheckStatus.NOT_CHECKED]}.",
        f"- Неполные фундаментальные поля кроме `cash`: {', '.join(non_cash_missing) or 'нет'}.",
        f"- Годы без строгого `cash`: {', '.join(map(str, cash_missing_years)) or 'нет'}.",
        f"- Годы вне основного стандарта МСФО: {', '.join(map(str, non_ifrs_years)) or 'нет'}.",
        f"- {fcf_absence_summary}",
        "", "## Проверка архива", "",
    ]
    if archive_errors:
        lines.extend(f"- {error}" for error in archive_errors)
    else:
        lines.append("Все локальные документы совпали с размером, SHA-256 и сигнатурой из реестра.")
    lines.extend([
        "", "## Полнота фундаментала", "",
        "| Год | Стандарт | Отсутствующие обязательные поля | FCF |",
        "| ---: | --- | --- | --- |",
    ])
    for year in years:
        standard = fundamental_by_year[year].standard
        missing = required_missing_by_year.get(year, [])
        fcf_status = "нет данных — 0 баллов" if year in fcf_missing_years else "подтверждён"
        lines.append(
            f"| {year} | {standard} | {', '.join(missing) if missing else 'нет'} | {fcf_status} |"
        )
    lines.extend([
        "", "## Решение шлюза данных", "",
        f"**Рейтинг {secid} не рассчитывается.** Причины:", "",
        "1. По MD-001/MD-002 `cash` — только денежные средства и эквиваленты, исходная валюта сохраняется без автоматической FX-конвертации. По MD-003 FCF считается только из денежных строк; отсутствие FCF даёт 0 баллов за год и само по себе не блокирует эмитента.",
        (
            "2. Остаются неполные обязательные фундаментальные поля: "
            f"{', '.join(non_cash_missing) or 'нет'}; годы без строгого cash: "
            f"{', '.join(map(str, cash_missing_years)) or 'нет'}."
            if non_cash_missing or cash_missing_years
            else (
                "2. Числовые поля заполнены, но годы вне основного стандарта МСФО: "
                f"{', '.join(map(str, non_ifrs_years))}. Методология v0.1 такие "
                "строки из рейтинга исключает; заполненность цифр не устраняет разрыв стандарта."
                if non_ifrs_years
                else "2. Неполных обязательных фундаментальных полей не осталось. "
                + (
                    f"Годы без FCF: {', '.join(map(str, fcf_missing_years))}; "
                    "они снижают компонент стабильности, но не являются причиной отказа."
                    if fcf_missing_years
                    else "FCF подтверждён за все годы."
                )
            )
        ),
        "3. Сопоставимый обезличенный снимок фундаментальных метрик Т-Банка не предоставлен; кросс-чек поэтому имеет статус `не проверен`.",
        (
            "4. В строгом дивидендном контракте пока нет фактов за календарные "
            f"годы: {', '.join(map(str, missing_dividend_years))}; "
            "неподтверждённый год не считается невыплатой."
            if missing_dividend_years
            else "4. Строгий дивидендный контракт 2021–2025 закрыт; это снимает "
            "только дивидендный разрыв и не отменяет остальные блокеры."
        ),
        "5. Историческая доступность инструмента на ИИС на дату сигнала не входит в этот доказательный пакет и должна быть подтверждена отдельно.",
        f"6. Секторный блок требует минимум 5 валидных нефинансовых эмитентов. Один {secid} не образует секторную выборку.",
        "7. Один эмитент и текущий набор документов не являются полноценным point-in-time ретро-набором против индекса.",
        "", "Это успешная проверка конвейера данных, а не положительный или отрицательный вывод об акции.",
    ])
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path

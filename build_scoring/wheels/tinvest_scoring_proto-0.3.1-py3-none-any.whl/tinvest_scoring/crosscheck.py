"""Кросс-чек обезличенного снимка Т-Банка с каноническими источниками."""
from __future__ import annotations

import csv
from dataclasses import dataclass
from datetime import date
from pathlib import Path

from .csvio import DataContractError, write_csv
from .models import CrosscheckRow, CrosscheckStatus, MetricObservation


@dataclass(frozen=True)
class TBankObservation:
    as_of: date
    issuer_id: str
    secid: str
    metric: str
    period: str
    value: float | str | None
    unit: str


TOLERANCES = {
    "price_close": (0.01, 0.0, "max(1% относительного, 0 абсолютного)"),
    "market_cap": (0.03, 0.0, "max(3% относительного, 0 абсолютного)"),
    "pe": (0.10, 0.0, "max(10% относительного, 0 абсолютного)"),
    "net_debt_ebitda": (0.10, 0.2, "max(10% относительного, 0,2x)") ,
    "roe_5": (0.10, 0.02, "max(10% относительного, 2 п.п.)"),
    "ebitda_margin_5": (0.10, 0.02, "max(10% относительного, 2 п.п.)"),
    "net_income": (0.10, 0.0, "10% относительного"),
    "ebitda": (0.10, 0.0, "10% относительного"),
    "fcf": (0.10, 0.0, "10% относительного"),
    "dividend_per_share": (
        0.01, 0.01, "max(1% относительного, 0,01 единицы указанной валюты)"
    ),
}
CATEGORICAL = {"sector", "share_class", "secid"}

CROSSCHECK_COLUMNS = [
    "as_of", "issuer_id", "secid", "metric", "external_source", "external_url",
    "external_period", "external_value", "tbank_period", "tbank_value", "abs_diff",
    "rel_diff_pct", "tolerance", "crosscheck_status", "used_in_score",
    "exclusion_reason",
]


def load_tbank_snapshot(path: Path) -> list[TBankObservation]:
    required = {"as_of", "issuer_id", "secid", "metric", "period", "value", "unit"}
    if not path.exists():
        raise DataContractError(f"Файл не найден: {path}")
    out = []
    seen = set()
    with path.open("r", encoding="utf-8-sig", newline="") as fh:
        reader = csv.DictReader(fh)
        missing = required - set(reader.fieldnames or [])
        if missing:
            raise DataContractError(
                f"{path}: отсутствуют столбцы: {', '.join(sorted(missing))}"
            )
        for raw in reader:
            row = {key: (value or "").strip() for key, value in raw.items()}
            value = _number_or_text(row["value"])
            item = TBankObservation(
                as_of=date.fromisoformat(row["as_of"]), issuer_id=row["issuer_id"],
                secid=row["secid"].upper(), metric=row["metric"], period=row["period"],
                value=value, unit=row["unit"],
            )
            key = (item.as_of, item.issuer_id, item.secid, item.metric)
            if key in seen:
                raise DataContractError(f"Дубликат строки Т-Банка: {key}")
            seen.add(key)
            out.append(item)
    return out


def compare(
    external: list[MetricObservation], tbank: list[TBankObservation]
) -> list[CrosscheckRow]:
    lookup = {
        (row.as_of, row.issuer_id, row.secid, row.metric): row for row in tbank
    }
    out = []
    for item in external:
        bank = lookup.get((item.as_of, item.issuer_id, item.secid, item.metric))
        if bank is None:
            out.append(_not_checked(item, "поле отсутствует в обезличенном снимке Т-Банка"))
            continue
        if bank.period != item.external_period:
            out.append(_not_checked(
                item, "периоды не совпадают", bank.period, bank.value
            ))
            continue
        if bank.unit.casefold() != item.unit.casefold():
            out.append(_not_checked(
                item, "единицы измерения не совпадают", bank.period, bank.value
            ))
            continue
        if item.external_value is None or bank.value is None:
            out.append(_not_checked(
                item, "одно из значений отсутствует", bank.period, bank.value
            ))
            continue
        if item.metric in CATEGORICAL:
            matched = str(item.external_value).strip().casefold() == str(bank.value).strip().casefold()
            out.append(CrosscheckRow(
                as_of=item.as_of, issuer_id=item.issuer_id, secid=item.secid,
                metric=item.metric, external_source=item.external_source,
                external_url=item.external_url, external_period=item.external_period,
                external_value=item.external_value, tbank_period=bank.period,
                tbank_value=bank.value, abs_diff=None, rel_diff_pct=None,
                tolerance="точное совпадение после нормализации регистра",
                status=CrosscheckStatus.MATCHED if matched else CrosscheckStatus.MISMATCHED,
                used_in_score=item.used_in_score, exclusion_reason=item.exclusion_reason,
            ))
            continue
        if item.metric not in TOLERANCES:
            out.append(_not_checked(
                item, "для показателя нет утверждённого допуска", bank.period, bank.value
            ))
            continue
        try:
            ext_value = float(item.external_value)
            bank_value = float(bank.value)
        except (TypeError, ValueError):
            out.append(_not_checked(
                item, "значения не являются числами", bank.period, bank.value
            ))
            continue
        abs_diff = abs(bank_value - ext_value)
        rel_diff = None if ext_value == 0 else abs_diff / abs(ext_value)
        rel_tol, abs_tol, label = TOLERANCES[item.metric]
        threshold = max(abs(ext_value) * rel_tol, abs_tol)
        status = (
            CrosscheckStatus.MATCHED if abs_diff <= threshold
            else CrosscheckStatus.MISMATCHED
        )
        out.append(CrosscheckRow(
            as_of=item.as_of, issuer_id=item.issuer_id, secid=item.secid,
            metric=item.metric, external_source=item.external_source,
            external_url=item.external_url, external_period=item.external_period,
            external_value=ext_value, tbank_period=bank.period, tbank_value=bank_value,
            abs_diff=abs_diff, rel_diff_pct=None if rel_diff is None else rel_diff * 100,
            tolerance=label, status=status, used_in_score=item.used_in_score,
            exclusion_reason=item.exclusion_reason,
        ))
    return out


def write_crosscheck_csv(path: Path, rows: list[CrosscheckRow]) -> Path:
    return write_csv(path, CROSSCHECK_COLUMNS, [
        {
            "as_of": row.as_of, "issuer_id": row.issuer_id, "secid": row.secid,
            "metric": row.metric, "external_source": row.external_source,
            "external_url": row.external_url, "external_period": row.external_period,
            "external_value": row.external_value, "tbank_period": row.tbank_period,
            "tbank_value": row.tbank_value, "abs_diff": row.abs_diff,
            "rel_diff_pct": row.rel_diff_pct, "tolerance": row.tolerance,
            "crosscheck_status": row.status.value, "used_in_score": row.used_in_score,
            "exclusion_reason": row.exclusion_reason,
        }
        for row in rows
    ])


def write_crosscheck_markdown(path: Path, rows: list[CrosscheckRow]) -> Path:
    counts = {status: sum(row.status == status for row in rows) for status in CrosscheckStatus}
    total = len(rows)
    mismatches = [row for row in rows if row.status == CrosscheckStatus.MISMATCHED]
    lines = [
        "# Кросс-чек-отчёт", "",
        "> Диагностический отчёт, не инвестиционная рекомендация. Значения Т-Банка не являются каноническим источником.",
        "", "## Покрытие", "",
        "| Статус | Строк | Доля |", "| --- | ---: | ---: |",
    ]
    for status in CrosscheckStatus:
        count = counts[status]
        share = "—" if not total else f"{count / total:.1%}"
        lines.append(f"| {status.value} | {count} | {share} |")
    if not total:
        lines.extend([
            "",
            "Сопоставимые строки отсутствуют: обезличенный снимок Т-Банка и внешний набор реальных эмитентов не предоставлены. Проценты не рассчитываются; это не считается совпадением данных.",
        ])
    lines.extend(["", "## Расхождения", ""])
    if not total:
        lines.append("Раздел неприменим: сравнимых строк нет.")
    elif all(row.status == CrosscheckStatus.NOT_CHECKED for row in rows):
        lines.append(
            "Сопоставимые пары отсутствуют: все строки имеют статус «не проверен». "
            "Это не означает совпадение."
        )
    elif not mismatches:
        lines.append("Расхождений среди проверенных сопоставимых строк не выявлено.")
    else:
        lines.extend([
            "| SECID | Показатель | Внешнее значение | Т-Банк | Расхождение |",
            "| --- | --- | ---: | ---: | ---: |",
        ])
        for row in mismatches:
            diff = "—" if row.rel_diff_pct is None else f"{row.rel_diff_pct:.2f}%"
            lines.append(
                f"| {row.secid} | {row.metric} | {row.external_value} | "
                f"{row.tbank_value} | {diff} |"
            )
    lines.extend([
        "", "## Правило использования", "",
        "Статус «не проверен» не превращается в ноль. При расхождении сохраняется официальное значение, если сущность, период, стандарт и единицы однозначны; иначе показатель исключается из балла.",
    ])
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def _not_checked(
    item: MetricObservation,
    reason: str,
    tbank_period: str = "",
    tbank_value: float | str | None = None,
) -> CrosscheckRow:
    return CrosscheckRow(
        as_of=item.as_of, issuer_id=item.issuer_id, secid=item.secid,
        metric=item.metric, external_source=item.external_source,
        external_url=item.external_url, external_period=item.external_period,
        external_value=item.external_value, tbank_period=tbank_period,
        tbank_value=tbank_value, abs_diff=None, rel_diff_pct=None,
        tolerance=TOLERANCES.get(item.metric, (0, 0, "нет утверждённого допуска"))[2],
        status=CrosscheckStatus.NOT_CHECKED, used_in_score=item.used_in_score,
        exclusion_reason="; ".join(filter(None, [item.exclusion_reason, reason])),
    )


def _number_or_text(value: str) -> float | str | None:
    if not value:
        return None
    try:
        return float(value.replace(" ", "").replace(",", "."))
    except ValueError:
        return value

"""Человекочитаемые и машинные отчёты скоринга."""
from __future__ import annotations

from pathlib import Path

from .csvio import write_csv
from .models import MetricObservation, ScoreResult

SCORE_COLUMNS = [
    "rank", "as_of", "issuer_id", "secid", "name", "sector", "status", "total",
    "debt_score", "profitability_score", "stability_score", "dividends_score",
    "liquidity_score", "net_debt_ebitda", "roe_median_5", "margin_median_5",
    "ni_positive_years", "fcf_positive_years", "fcf_missing_years",
    "paid_years_5", "payout_median",
    "turnover_median_60", "sessions_60", "passes_minimum", "explanation", "reasons",
]

OBSERVATION_COLUMNS = [
    "as_of", "issuer_id", "secid", "metric", "external_source", "external_url",
    "external_period", "external_value", "unit", "used_in_score", "exclusion_reason",
]


def write_scores(path: Path, results: list[ScoreResult]) -> Path:
    rank = 0
    rows = []
    for item in results:
        if item.total is not None:
            rank += 1
            current_rank: int | str = rank
        else:
            current_rank = ""
        rows.append({
            "rank": current_rank, "as_of": item.as_of, "issuer_id": item.issuer_id,
            "secid": item.secid, "name": item.name, "sector": item.sector,
            "status": item.status, "total": item.total, "debt_score": item.debt_score,
            "profitability_score": item.profitability_score,
            "stability_score": item.stability_score,
            "dividends_score": item.dividends_score,
            "liquidity_score": item.liquidity_score,
            "net_debt_ebitda": item.net_debt_ebitda,
            "roe_median_5": item.roe_median_5,
            "margin_median_5": item.margin_median_5,
            "ni_positive_years": item.ni_positive_years,
            "fcf_positive_years": item.fcf_positive_years,
            "fcf_missing_years": item.fcf_missing_years,
            "paid_years_5": item.paid_years_5,
            "payout_median": item.payout_median,
            "turnover_median_60": item.turnover_median_60,
            "sessions_60": item.sessions_60,
            "passes_minimum": item.passes_score,
            "explanation": item.explanation(), "reasons": "; ".join(item.reasons),
        })
    return write_csv(path, SCORE_COLUMNS, rows)


def write_observations(path: Path, results: list[ScoreResult]) -> Path:
    observations = [obs for result in results for obs in result.observations]
    return write_csv(path, OBSERVATION_COLUMNS, [observation_row(row) for row in observations])


def observation_row(row: MetricObservation) -> dict:
    return {
        "as_of": row.as_of, "issuer_id": row.issuer_id, "secid": row.secid,
        "metric": row.metric, "external_source": row.external_source,
        "external_url": row.external_url, "external_period": row.external_period,
        "external_value": row.external_value, "unit": row.unit,
        "used_in_score": row.used_in_score, "exclusion_reason": row.exclusion_reason,
    }


def write_score_markdown(path: Path, results: list[ScoreResult], top_n: int) -> Path:
    ranked = [row for row in results if row.total is not None][:top_n]
    lines = [
        "# Скоринг-лист v0.1", "",
        "> Не инвестиционная рекомендация. Список показывает прохождение заранее утверждённых правил качества; решение принимает Роман.",
        "",
    ]
    if not ranked:
        lines.append("Ни одна бумага не получила рассчитываемый балл.")
    else:
        lines.extend([
            "| Место | SECID | Балл | Статус порога | Почему |",
            "| ---: | --- | ---: | --- | --- |",
        ])
        for index, item in enumerate(ranked, 1):
            threshold = "проходит" if item.passes_score else "не проходит"
            lines.append(
                f"| {index} | {item.secid} | {item.total} | {threshold} | "
                f"{item.explanation()} |"
            )
    blocked = [row for row in results if row.total is None]
    lines.extend(["", "## Неоценённые бумаги", ""])
    if blocked:
        for item in blocked:
            lines.append(f"- `{item.secid}` — {item.explanation()}")
    else:
        lines.append("Нет.")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path

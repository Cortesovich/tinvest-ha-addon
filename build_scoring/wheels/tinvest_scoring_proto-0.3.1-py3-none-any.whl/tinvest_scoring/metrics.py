"""Нормализация производных финансовых показателей.

Модуль не загружает данные и не взаимодействует с брокером. Он только
воспроизводимо считает показатели из уже подтверждённых денежных строк.
"""

from __future__ import annotations


def cash_free_cash_flow(
    operating_cash_flow: float | None,
    ppe_and_intangibles_cash_outflow: float | None,
) -> float | None:
    """Рассчитать FCF по MD-003 в единицах исходной отчётности.

    ``ppe_and_intangibles_cash_outflow`` передаётся положительной величиной
    фактических денежных покупок ОС и НМА. Если хотя бы один компонент не
    подтверждён, результат остаётся отсутствующим: подстановка нуля запрещена.
    """

    if operating_cash_flow is None or ppe_and_intangibles_cash_outflow is None:
        return None
    if ppe_and_intangibles_cash_outflow < 0:
        raise ValueError(
            "Денежный отток на ОС и НМА должен быть передан положительной величиной"
        )
    return operating_cash_flow - ppe_and_intangibles_cash_outflow

"""Строгий CSV-контракт для внешних и обезличенных данных."""
from __future__ import annotations

import csv
from dataclasses import fields, is_dataclass
from datetime import date, datetime
from pathlib import Path
from typing import Iterable

from .models import (
    CorporateAction,
    DividendRecord,
    FundamentalRecord,
    IndexPoint,
    Instrument,
    MarketBar,
    MetricObservation,
    SourceRef,
)


class DataContractError(ValueError):
    """Входной файл нельзя однозначно интерпретировать."""


def _rows(path: Path, required: set[str]) -> list[dict[str, str]]:
    if not path.exists():
        raise DataContractError(f"Файл не найден: {path}")
    with path.open("r", encoding="utf-8-sig", newline="") as fh:
        reader = csv.DictReader(fh)
        actual = set(reader.fieldnames or [])
        missing = required - actual
        if missing:
            raise DataContractError(
                f"{path}: отсутствуют столбцы: {', '.join(sorted(missing))}"
            )
        return [{k: (v or "").strip() for k, v in row.items()} for row in reader]


def _date(value: str, field_name: str, *, optional: bool = False) -> date | None:
    if not value and optional:
        return None
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise DataContractError(f"{field_name}: нужна дата YYYY-MM-DD, получено {value!r}") from exc


def _float(value: str, field_name: str, *, optional: bool = False) -> float | None:
    if not value and optional:
        return None
    try:
        return float(value.replace(" ", "").replace(",", "."))
    except ValueError as exc:
        raise DataContractError(f"{field_name}: нужно число, получено {value!r}") from exc


def _int(value: str, field_name: str, *, optional: bool = False) -> int | None:
    number = _float(value, field_name, optional=optional)
    if number is None:
        return None
    if not number.is_integer():
        raise DataContractError(f"{field_name}: нужно целое число, получено {value!r}")
    return int(number)


def _bool(value: str, field_name: str) -> bool:
    normalized = value.casefold()
    if normalized in {"1", "true", "yes", "да"}:
        return True
    if normalized in {"0", "false", "no", "нет"}:
        return False
    raise DataContractError(f"{field_name}: допустимы true/false, получено {value!r}")


def _datetime(value: str, field_name: str) -> datetime:
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise DataContractError(
            f"{field_name}: нужен ISO-8601 timestamp, получено {value!r}"
        ) from exc


def _source(row: dict[str, str]) -> SourceRef:
    src = SourceRef(
        name=row["source_name"],
        url=row["source_url"],
        tier=row["source_tier"].upper(),
        verified=_bool(row["source_verified"], "source_verified"),
        normalizer_name=row["normalizer_name"],
        normalizer_url=row["normalizer_url"],
        loaded_at=_datetime(row["loaded_at"], "loaded_at"),
    )
    if not src.name or not src.url:
        raise DataContractError("У каждой записи обязательны source_name и source_url")
    if src.tier not in {"A", "B", "C"}:
        raise DataContractError(f"source_tier: допустимы A/B/C, получено {src.tier!r}")
    return src


SOURCE_COLUMNS = {
    "source_name", "source_url", "source_tier", "source_verified",
    "normalizer_name", "normalizer_url", "loaded_at",
}


def load_instruments(path: Path) -> list[Instrument]:
    required = {
        "issuer_id", "secid", "name", "sector", "share_class", "boardid",
        "listing_from", "listing_till", "iis_eligible", "iis_checked_as_of",
        "iis_valid_from", "iis_valid_till",
        "financial_sector", "unresolved_corporate_action", *SOURCE_COLUMNS,
    }
    out: list[Instrument] = []
    for row in _rows(path, required):
        out.append(Instrument(
            issuer_id=row["issuer_id"], secid=row["secid"].upper(), name=row["name"],
            sector=row["sector"], share_class=row["share_class"],
            boardid=row["boardid"].upper(),
            listing_from=_date(row["listing_from"], "listing_from"),
            listing_till=_date(row["listing_till"], "listing_till", optional=True),
            iis_eligible=_bool(row["iis_eligible"], "iis_eligible"),
            iis_checked_as_of=_date(row["iis_checked_as_of"], "iis_checked_as_of", optional=True),
            iis_valid_from=_date(row["iis_valid_from"], "iis_valid_from", optional=True),
            iis_valid_till=_date(row["iis_valid_till"], "iis_valid_till", optional=True),
            financial_sector=_bool(row["financial_sector"], "financial_sector"),
            unresolved_corporate_action=_bool(
                row["unresolved_corporate_action"], "unresolved_corporate_action"
            ),
            source=_source(row),
        ))
    return out


def load_fundamentals(path: Path) -> list[FundamentalRecord]:
    value_columns = {
        "revenue", "ebitda", "net_income", "equity", "interest_debt", "cash", "fcf"
    }
    required = {
        "issuer_id", "secid", "fiscal_year", "period_end", "publication_date",
        "standard", "currency", "scale", "version_id", "restated",
        *value_columns, *SOURCE_COLUMNS,
    }
    out: list[FundamentalRecord] = []
    for row in _rows(path, required):
        source = _source(row)
        if not source.normalizer_name or not source.normalizer_url:
            raise DataContractError(
                "Фундаментальная запись обязана иметь normalizer_name и normalizer_url"
            )
        record = FundamentalRecord(
            issuer_id=row["issuer_id"], secid=row["secid"].upper(),
            fiscal_year=_int(row["fiscal_year"], "fiscal_year"),
            period_end=_date(row["period_end"], "period_end"),
            publication_date=_date(row["publication_date"], "publication_date"),
            standard=row["standard"].upper(), currency=row["currency"].upper(),
            scale=_float(row["scale"], "scale"),
            revenue=_float(row["revenue"], "revenue", optional=True),
            ebitda=_float(row["ebitda"], "ebitda", optional=True),
            net_income=_float(row["net_income"], "net_income", optional=True),
            equity=_float(row["equity"], "equity", optional=True),
            interest_debt=_float(row["interest_debt"], "interest_debt", optional=True),
            cash=_float(row["cash"], "cash", optional=True),
            fcf=_float(row["fcf"], "fcf", optional=True),
            version_id=row["version_id"], restated=_bool(row["restated"], "restated"),
            source=source,
        )
        if not _valid_currency(record.currency) or record.scale <= 0:
            raise DataContractError(
                "Фундаментальная запись требует код валюты ISO-4217 и положительный scale"
            )
        out.append(record)
    return out


def load_dividends(path: Path) -> list[DividendRecord]:
    required = {
        "issuer_id", "secid", "payment_year", "payment_date", "fiscal_year",
        "amount_per_share", "total_amount", "currency", "total_amount_scale",
        "was_paid", "verification_date",
        *SOURCE_COLUMNS,
    }
    out: list[DividendRecord] = []
    for row in _rows(path, required):
        record = DividendRecord(
            issuer_id=row["issuer_id"], secid=row["secid"].upper(),
            payment_year=_int(row["payment_year"], "payment_year"),
            payment_date=_date(row["payment_date"], "payment_date", optional=True),
            fiscal_year=_int(row["fiscal_year"], "fiscal_year", optional=True),
            amount_per_share=_float(row["amount_per_share"], "amount_per_share", optional=True),
            total_amount=_float(row["total_amount"], "total_amount", optional=True),
            currency=row["currency"].upper(),
            total_amount_scale=_float(row["total_amount_scale"], "total_amount_scale"),
            was_paid=_bool(row["was_paid"], "was_paid"),
            verification_date=_date(row["verification_date"], "verification_date"),
            source=_source(row),
        )
        # Для балла дивидендной истории достаточно официального подтверждения
        # факта выплаты в завершённом календарном году. Годовые отчёты нередко
        # раскрывают только месяц выплаты или агрегат за год; точную дату,
        # fiscal year и сумму на акцию в таком случае оставляем пустыми, а не
        # изобретаем. Эти пропуски отдельно блокируют payout/ретро-событие там,
        # где соответствующая детализация действительно нужна.
        if not _valid_currency(record.currency) or record.total_amount_scale <= 0:
            raise DataContractError(
                "Дивидендная запись требует код валюты ISO-4217 и положительный total_amount_scale"
            )
        if not record.source.normalizer_name or not record.source.normalizer_url:
            raise DataContractError(
                "Дивидендная запись обязана иметь normalizer_name и normalizer_url"
            )
        out.append(record)
    return out


def _valid_currency(value: str) -> bool:
    return len(value) == 3 and value.isascii() and value.isalpha() and value.isupper()


def load_market_bars(path: Path) -> list[MarketBar]:
    required = {"secid", "trade_date", "open", "close", "value", "volume"}
    return [
        MarketBar(
            secid=row["secid"].upper(), trade_date=_date(row["trade_date"], "trade_date"),
            open=_float(row["open"], "open", optional=True),
            close=_float(row["close"], "close", optional=True),
            value=_float(row["value"], "value", optional=True),
            volume=_float(row["volume"], "volume", optional=True),
        )
        for row in _rows(path, required)
    ]


def load_index_points(path: Path) -> list[IndexPoint]:
    required = {"secid", "trade_date", "close"}
    return [
        IndexPoint(
            secid=row["secid"].upper(), trade_date=_date(row["trade_date"], "trade_date"),
            close=_float(row["close"], "close"),
        )
        for row in _rows(path, required)
    ]


def load_corporate_actions(path: Path) -> list[CorporateAction]:
    required = {
        "action_date", "issuer_id", "old_secid", "new_secid", "action_type",
        "share_factor", "cash_per_old_share", *SOURCE_COLUMNS,
    }
    allowed = {
        "split", "consolidation", "ticker_change", "delisting", "reorganization",
        "additional_issue",
    }
    out = []
    for row in _rows(path, required):
        action_type = row["action_type"].casefold()
        if action_type not in allowed:
            raise DataContractError(
                f"action_type: допустимы {', '.join(sorted(allowed))}, получено {action_type!r}"
            )
        item = CorporateAction(
            action_date=_date(row["action_date"], "action_date"),
            issuer_id=row["issuer_id"], old_secid=row["old_secid"].upper(),
            new_secid=row["new_secid"].upper(), action_type=action_type,
            share_factor=_float(row["share_factor"], "share_factor", optional=True),
            cash_per_old_share=_float(
                row["cash_per_old_share"], "cash_per_old_share", optional=True
            ), source=_source(row),
        )
        if action_type in {"split", "consolidation"} and (
            item.share_factor is None or item.share_factor <= 0
        ):
            raise DataContractError(f"{action_type}: нужен положительный share_factor")
        if not item.source.verified or item.source.tier not in {"A", "B"}:
            raise DataContractError("Корпоративное событие требует проверенного источника A/B")
        out.append(item)
    return out


def load_metric_observations(path: Path) -> list[MetricObservation]:
    required = {
        "as_of", "issuer_id", "secid", "metric", "external_source", "external_url",
        "external_period", "external_value", "unit", "used_in_score", "exclusion_reason",
    }
    out = []
    for row in _rows(path, required):
        raw = row["external_value"]
        try:
            value: float | str | None = _float(raw, "external_value", optional=True)
        except DataContractError:
            value = raw or None
        out.append(MetricObservation(
            as_of=_date(row["as_of"], "as_of"), issuer_id=row["issuer_id"],
            secid=row["secid"].upper(), metric=row["metric"],
            external_source=row["external_source"], external_url=row["external_url"],
            external_period=row["external_period"], external_value=value, unit=row["unit"],
            used_in_score=_bool(row["used_in_score"], "used_in_score"),
            exclusion_reason=row["exclusion_reason"],
        ))
    return out


def write_csv(path: Path, columns: list[str], rows: Iterable[dict]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({key: _cell(row.get(key)) for key in columns})
    return path


def dataclass_row(value) -> dict:
    if not is_dataclass(value):
        raise TypeError("Ожидался dataclass")
    return {field.name: getattr(value, field.name) for field in fields(value)}


def _cell(value):
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, bool):
        return str(value).lower()
    if value is None:
        return ""
    return value

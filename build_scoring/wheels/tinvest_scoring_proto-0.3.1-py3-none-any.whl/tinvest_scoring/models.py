"""Типы данных прототипа.

Модели намеренно не содержат брокерских счетов, токенов и методов отправки
заявок. Единственная внешняя интеграция пакета — публичный MOEX ISS по GET.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime
from enum import StrEnum


class CrosscheckStatus(StrEnum):
    MATCHED = "совпал"
    MISMATCHED = "расходится"
    NOT_CHECKED = "не проверен"


@dataclass(frozen=True)
class SourceRef:
    name: str
    url: str
    tier: str
    verified: bool
    normalizer_name: str = ""
    normalizer_url: str = ""
    loaded_at: datetime | None = None


@dataclass(frozen=True)
class Instrument:
    issuer_id: str
    secid: str
    name: str
    sector: str
    share_class: str
    boardid: str
    listing_from: date
    listing_till: date | None
    iis_eligible: bool
    iis_checked_as_of: date | None
    iis_valid_from: date | None
    iis_valid_till: date | None
    financial_sector: bool
    unresolved_corporate_action: bool
    source: SourceRef

    def listed_on(self, as_of: date) -> bool:
        return self.listing_from <= as_of and (
            self.listing_till is None or as_of <= self.listing_till
        )

    def iis_available_on(self, as_of: date) -> bool:
        return self.iis_eligible and (
            self.iis_valid_from is None or self.iis_valid_from <= as_of
        ) and (
            self.iis_valid_till is None or as_of <= self.iis_valid_till
        )


@dataclass(frozen=True)
class FundamentalRecord:
    issuer_id: str
    secid: str
    fiscal_year: int
    period_end: date
    publication_date: date
    standard: str
    currency: str
    scale: float
    revenue: float | None
    ebitda: float | None
    net_income: float | None
    equity: float | None
    interest_debt: float | None
    cash: float | None
    fcf: float | None
    version_id: str
    restated: bool
    source: SourceRef

    def value_scaled(self, field_name: str) -> float | None:
        """Вернуть значение в единицах исходной валюты после применения scale."""
        value = getattr(self, field_name)
        if value is None:
            return None
        return value * self.scale

    def value_rub(self, field_name: str) -> float | None:
        """Совместимый помощник только для явно рублёвых наблюдений."""
        value = self.value_scaled(field_name)
        if value is None:
            return None
        if self.currency != "RUB":
            return None
        return value


@dataclass(frozen=True)
class DividendRecord:
    issuer_id: str
    secid: str
    payment_year: int
    payment_date: date | None
    fiscal_year: int | None
    amount_per_share: float | None
    total_amount: float | None
    currency: str
    total_amount_scale: float
    was_paid: bool
    verification_date: date
    source: SourceRef

    def total_amount_scaled(self) -> float | None:
        """Вернуть issuer-level сумму в единицах указанной валюты."""
        if self.total_amount is None:
            return None
        return self.total_amount * self.total_amount_scale

    def total_amount_rub(self) -> float | None:
        """Совместимый помощник только для явно рублёвых выплат."""
        value = self.total_amount_scaled()
        if value is None or self.currency != "RUB":
            return None
        return value


@dataclass(frozen=True)
class MarketBar:
    secid: str
    trade_date: date
    open: float | None
    close: float | None
    value: float | None
    volume: float | None


@dataclass(frozen=True)
class IndexPoint:
    secid: str
    trade_date: date
    close: float


@dataclass(frozen=True)
class CorporateAction:
    action_date: date
    issuer_id: str
    old_secid: str
    new_secid: str
    action_type: str
    share_factor: float | None
    cash_per_old_share: float | None
    source: SourceRef


@dataclass(frozen=True)
class MetricObservation:
    as_of: date
    issuer_id: str
    secid: str
    metric: str
    external_source: str
    external_url: str
    external_period: str
    external_value: float | str | None
    unit: str
    used_in_score: bool
    exclusion_reason: str = ""


@dataclass
class ScoreResult:
    issuer_id: str
    secid: str
    name: str
    sector: str
    as_of: date
    status: str
    total: int | None
    debt_score: int = 0
    profitability_score: int = 0
    stability_score: int = 0
    dividends_score: int = 0
    liquidity_score: int = 0
    debt_computed: bool = False
    profitability_computed: bool = False
    stability_computed: bool = False
    dividends_computed: bool = False
    liquidity_computed: bool = False
    sector_candidate: bool = False
    net_debt_ebitda: float | None = None
    roe_median_5: float | None = None
    margin_median_5: float | None = None
    ni_positive_years: int | None = None
    fcf_positive_years: int | None = None
    fcf_missing_years: int | None = None
    paid_years_5: int | None = None
    payout_median: float | None = None
    turnover_median_60: float | None = None
    sessions_60: int = 0
    reasons: list[str] = field(default_factory=list)
    observations: list[MetricObservation] = field(default_factory=list)

    @property
    def passes_score(self) -> bool:
        return self.status == "допущено" and self.total is not None and self.total >= 60

    def explanation(self) -> str:
        if self.total is None:
            return "; ".join(self.reasons) or "балл не рассчитан"
        summary = (
            f"долг {self.debt_score}/25 (ND/EBITDA={self.net_debt_ebitda:.2f}); "
            f"рентабельность {self.profitability_score}/20 "
            f"(ROE5={self.roe_median_5:.1%}, margin5={self.margin_median_5:.1%}); "
            f"стабильность {self.stability_score}/20 "
            f"(прибыль {self.ni_positive_years}/5, FCF положительный "
            f"{self.fcf_positive_years}/5, нет данных {self.fcf_missing_years}/5); "
            f"дивиденды {self.dividends_score}/20 (выплаты {self.paid_years_5}/5); "
            f"ликвидность {self.liquidity_score}/15 "
            f"(медиана {self.turnover_median_60 / 1_000_000:.1f} млн руб.)"
        )
        if self.reasons:
            summary += "; примечания: " + "; ".join(self.reasons)
        return summary


@dataclass(frozen=True)
class CrosscheckRow:
    as_of: date
    issuer_id: str
    secid: str
    metric: str
    external_source: str
    external_url: str
    external_period: str
    external_value: float | str | None
    tbank_period: str
    tbank_value: float | str | None
    abs_diff: float | None
    rel_diff_pct: float | None
    tolerance: str
    status: CrosscheckStatus
    used_in_score: bool
    exclusion_reason: str

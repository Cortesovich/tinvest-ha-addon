"""Формула скоринга v0.1, буквально следующая ``методология.md``."""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from datetime import date
from statistics import median

from .models import (
    DividendRecord,
    FundamentalRecord,
    Instrument,
    MarketBar,
    MetricObservation,
    ScoreResult,
)

MIN_TURNOVER = 10_000_000.0
MIN_SESSIONS = 55
TARGET_SESSIONS = 60


@dataclass
class _Prepared:
    instrument: Instrument
    result: ScoreResult
    annual: dict[int, FundamentalRecord]


def score_universe(
    *,
    as_of: date,
    instruments: list[Instrument],
    fundamentals: list[FundamentalRecord],
    dividends: list[DividendRecord],
    market_bars: list[MarketBar],
    operation_amount: float,
) -> list[ScoreResult]:
    """Рассчитать рейтинг всей доступной вселенной на одну дату.

    ``operation_amount`` — исследовательский размер одной операции. Функция
    ничего не исполняет и не знает о брокерском счёте.
    """
    if operation_amount <= 0:
        raise ValueError("operation_amount должен быть положительным")

    fund_by_issuer: dict[str, list[FundamentalRecord]] = defaultdict(list)
    div_by_issuer: dict[str, list[DividendRecord]] = defaultdict(list)
    bars_by_secid: dict[str, list[MarketBar]] = defaultdict(list)
    for row in fundamentals:
        fund_by_issuer[row.issuer_id].append(row)
    for row in dividends:
        div_by_issuer[row.issuer_id].append(row)
    for row in market_bars:
        if row.trade_date <= as_of:
            bars_by_secid[row.secid].append(row)
    session_calendar = sorted({
        row.trade_date for row in market_bars if row.trade_date <= as_of
    })[-TARGET_SESSIONS:]

    candidates: list[_Prepared] = []
    rejected: list[ScoreResult] = []
    for instrument in instruments:
        base = ScoreResult(
            issuer_id=instrument.issuer_id, secid=instrument.secid, name=instrument.name,
            sector=instrument.sector, as_of=as_of, status="данных недостаточно", total=None,
        )
        universe_reason = _universe_rejection(instrument, as_of)
        if universe_reason:
            base.status = "не допущено"
            base.reasons.append(universe_reason)
            rejected.append(base)
            continue
        prepared = _prepare_one(
            as_of, instrument, fund_by_issuer[instrument.issuer_id],
            div_by_issuer[instrument.issuer_id], bars_by_secid[instrument.secid],
            session_calendar, operation_amount,
        )
        if prepared.result.total is None and prepared.result.status != "к расчёту":
            rejected.append(prepared.result)
        else:
            candidates.append(prepared)

    # Один, самый ликвидный, класс акции эмитента.
    best_by_issuer: dict[str, _Prepared] = {}
    for item in candidates:
        old = best_by_issuer.get(item.instrument.issuer_id)
        new_key = (item.result.turnover_median_60 or 0.0, item.instrument.secid)
        old_key = (old.result.turnover_median_60 or 0.0, old.instrument.secid) if old else None
        if old is None or new_key > old_key:
            if old is not None:
                old.result.status = "не допущено"
                old.result.total = None
                old.result.reasons.append("выбран более ликвидный класс акций эмитента")
                rejected.append(old.result)
            best_by_issuer[item.instrument.issuer_id] = item
        else:
            item.result.status = "не допущено"
            item.result.total = None
            item.result.reasons.append("выбран более ликвидный класс акций эмитента")
            rejected.append(item.result)
    candidates = list(best_by_issuer.values())

    sector_groups: dict[str, list[_Prepared]] = defaultdict(list)
    for item in candidates:
        sector_groups[item.instrument.sector].append(item)

    accepted: list[ScoreResult] = []
    for sector, group in sector_groups.items():
        for item in group:
            item.result.sector_candidate = True
        if len(group) < 5:
            for item in group:
                item.result.status = "данных недостаточно"
                item.result.total = None
                item.result.reasons.append(
                    f"в секторе {sector!r} только {len(group)} валидных эмитентов; нужно не менее 5"
                )
                rejected.append(item.result)
            continue
        roe_pct = _percentiles({x.instrument.issuer_id: x.result.roe_median_5 for x in group})
        margin_pct = _percentiles({x.instrument.issuer_id: x.result.margin_median_5 for x in group})
        for item in group:
            roe_score = _quartile_score(roe_pct[item.instrument.issuer_id])
            margin_score = _quartile_score(margin_pct[item.instrument.issuer_id])
            result = item.result
            result.profitability_score = roe_score + margin_score
            result.profitability_computed = True
            result.total = (
                result.debt_score + result.profitability_score + result.stability_score
                + result.dividends_score + result.liquidity_score
            )
            result.status = "допущено"
            result.observations.extend(_profitability_observations(result, item.annual))
            accepted.append(result)

    all_results = accepted + rejected
    all_results.sort(key=_sort_key)
    return all_results


def _prepare_one(
    as_of: date,
    instrument: Instrument,
    records: list[FundamentalRecord],
    dividends: list[DividendRecord],
    bars: list[MarketBar],
    session_calendar: list[date],
    operation_amount: float,
) -> _Prepared:
    result = ScoreResult(
        issuer_id=instrument.issuer_id, secid=instrument.secid, name=instrument.name,
        sector=instrument.sector, as_of=as_of, status="к расчёту", total=0,
    )
    result.observations.extend(_instrument_observations(instrument, as_of))

    annual, error = _point_in_time_annual(records, as_of)
    if error:
        return _blocked(instrument, result, error, status="данных недостаточно", annual=annual)

    completed_years = list(range(as_of.year - 5, as_of.year))
    previous_year = as_of.year - 6
    needed = [previous_year, *completed_years]
    missing_years = [year for year in needed if year not in annual]
    if missing_years:
        return _blocked(
            instrument, result,
            f"нет point-in-time МСФО за годы: {', '.join(map(str, missing_years))}",
            status="данных недостаточно", annual=annual,
        )

    currencies = {annual[year].currency.upper() for year in needed}
    if len(currencies) != 1 or not next(iter(currencies), ""):
        labels = ", ".join(
            f"{year}={annual[year].currency or 'пусто'}" for year in needed
        )
        return _blocked(
            instrument, result,
            f"валюта фундаментального ряда не едина: {labels}",
            status="данных недостаточно", annual=annual,
        )

    series = [annual[year] for year in completed_years]
    # MD-003: отсутствие FCF снижает балл стабильности, но само по себе не
    # исключает эмитента. Остальные поля остаются обязательными.
    required = ("revenue", "ebitda", "net_income", "equity")
    for record in series:
        missing = [field for field in required if record.value_scaled(field) is None]
        if missing:
            return _blocked(
                instrument, result,
                f"{record.fiscal_year}: отсутствуют надёжные поля {', '.join(missing)}",
                status="данных недостаточно", annual=annual,
            )
    if annual[previous_year].value_scaled("equity") is None:
        return _blocked(
            instrument, result, f"нет капитала на начало {completed_years[0]} года",
            status="данных недостаточно", annual=annual,
        )

    latest = annual[as_of.year - 1]
    if latest.value_scaled("interest_debt") is None or latest.value_scaled("cash") is None:
        return _blocked(
            instrument, result, "нет долга или денежных средств последнего года",
            status="данных недостаточно", annual=annual,
        )

    ebitda = latest.value_scaled("ebitda")
    if ebitda <= 0:
        return _blocked(instrument, result, "EBITDA последнего года <= 0", annual=annual)
    net_debt = latest.value_scaled("interest_debt") - latest.value_scaled("cash")
    nd_ebitda = net_debt / ebitda
    result.net_debt_ebitda = nd_ebitda
    if nd_ebitda > 3:
        return _blocked(instrument, result, "Net Debt/EBITDA > 3,0", annual=annual)
    result.debt_score = _debt_score(nd_ebitda)
    result.debt_computed = True

    roes = []
    margins = []
    for year in completed_years:
        current = annual[year]
        previous = annual[year - 1]
        average_equity = (
            previous.value_scaled("equity") + current.value_scaled("equity")
        ) / 2
        revenue = current.value_scaled("revenue")
        if average_equity == 0 or revenue == 0:
            return _blocked(
                instrument, result, f"нулевой знаменатель ROE/margin за {year}",
                status="данных недостаточно", annual=annual,
            )
        roes.append(current.value_scaled("net_income") / average_equity)
        margins.append(current.value_scaled("ebitda") / revenue)
    result.roe_median_5 = median(roes)
    result.margin_median_5 = median(margins)
    if result.roe_median_5 <= 0:
        return _blocked(instrument, result, "медианный ROE за 5 лет <= 0", annual=annual)
    if result.margin_median_5 <= 0:
        return _blocked(
            instrument, result, "медианная EBITDA margin за 5 лет <= 0", annual=annual
        )

    result.ni_positive_years = sum(r.value_scaled("net_income") > 0 for r in series)
    fcf_values = [r.value_scaled("fcf") for r in series]
    result.fcf_positive_years = sum(value is not None and value > 0 for value in fcf_values)
    result.fcf_missing_years = sum(value is None for value in fcf_values)
    if result.fcf_missing_years:
        missing_fcf_years = [
            record.fiscal_year for record, value in zip(series, fcf_values)
            if value is None
        ]
        result.reasons.append(
            "FCF: нет подтверждённых данных за годы "
            f"{', '.join(map(str, missing_fcf_years))}; "
            "по MD-003 начислено 0 баллов за каждый отсутствующий год"
        )
    if result.ni_positive_years < 3:
        return _blocked(
            instrument, result, "положительная чистая прибыль менее чем в 3 из 5 лет",
            annual=annual,
        )
    positive_equity = sum(r.value_scaled("equity") > 0 for r in series)
    if positive_equity < 4:
        return _blocked(
            instrument, result, "положительный капитал менее чем в 4 из 5 лет", annual=annual
        )
    result.stability_score = 2 * result.ni_positive_years + 2 * result.fcf_positive_years
    result.stability_computed = True
    result.observations.extend(_stability_observations(result, annual))

    div_error = _score_dividends(result, dividends, annual, as_of)
    if div_error:
        return _blocked(
            instrument, result, div_error, status="данных недостаточно", annual=annual
        )

    liquidity_error = _score_liquidity(
        result, bars, session_calendar, as_of, operation_amount
    )
    if liquidity_error:
        return _blocked(instrument, result, liquidity_error, annual=annual)

    result.observations.extend(_base_observations(result, latest))
    return _Prepared(instrument=instrument, result=result, annual=annual)


def _point_in_time_annual(
    records: list[FundamentalRecord], as_of: date
) -> tuple[dict[int, FundamentalRecord], str | None]:
    eligible = [
        row for row in records
        if row.publication_date <= as_of and row.period_end <= as_of
        and row.standard in {"IFRS", "МСФО"} and bool(row.currency)
        and row.source.verified and row.source.tier in {"A", "B"}
        and row.source.url and row.source.loaded_at is not None
        and row.source.normalizer_name and row.source.normalizer_url and row.version_id
    ]
    by_year: dict[int, list[FundamentalRecord]] = defaultdict(list)
    for row in eligible:
        by_year[row.fiscal_year].append(row)
    selected = {
        year: sorted(rows, key=lambda x: (x.publication_date, x.version_id))[-1]
        for year, rows in by_year.items()
    }
    if records and not eligible:
        return selected, "нет подтверждённых point-in-time записей МСФО"
    return selected, None


def _score_dividends(
    result: ScoreResult,
    records: list[DividendRecord],
    annual: dict[int, FundamentalRecord],
    as_of: date,
) -> str | None:
    known = [
        row for row in records
        if row.verification_date <= as_of and row.source.verified
        and row.source.tier in {"A", "B"} and row.source.url
        and row.source.loaded_at is not None
        and _paid_fact_is_known_as_of(row, as_of)
    ]
    completed_calendar_years = list(range(as_of.year - 5, as_of.year))
    by_payment_year: dict[int, list[DividendRecord]] = defaultdict(list)
    for row in known:
        by_payment_year[row.payment_year].append(row)
    missing = [year for year in completed_calendar_years if year not in by_payment_year]
    if missing:
        return (
            "нет подтверждения выплаты/невыплаты дивидендов за годы: "
            + ", ".join(map(str, missing))
        )
    result.paid_years_5 = sum(
        any(row.was_paid for row in by_payment_year[year])
        for year in completed_calendar_years
    )
    history_score = 2 * result.paid_years_5
    payout_score = 0
    if result.paid_years_5 >= 3:
        target_fy = set(range(as_of.year - 5, as_of.year))
        relevant_paid = [
            row for year in completed_calendar_years
            for row in by_payment_year[year] if row.was_paid
        ]
        paid = [row for row in relevant_paid if row.fiscal_year in target_fy]
        if any(row.fiscal_year is None for row in relevant_paid):
            result.reasons.append(
                "payout score=0: неоднозначная привязка фактической выплаты "
                "к финансовому году"
            )
        elif any(row.fiscal_year not in annual for row in paid):
            result.reasons.append(
                "payout score=0: нет сопоставимой чистой прибыли финансового года"
            )
        elif any(row.total_amount_scaled() is None for row in paid):
            result.reasons.append("payout score=0: у выплаты нет issuer-level total_amount")
        elif any(
            row.currency.upper() != annual[row.fiscal_year].currency.upper()
            for row in paid
        ):
            result.reasons.append(
                "payout score=0: валюта выплаты не совпадает с валютой чистой прибыли"
            )
        elif any(annual[row.fiscal_year].value_scaled("net_income") <= 0 for row in paid):
            result.reasons.append("payout score=0: выплата относится к году с неположительной прибылью")
        elif paid:
            totals: dict[int, float] = defaultdict(float)
            for row in paid:
                totals[row.fiscal_year] += row.total_amount_scaled()
            ratios = [
                amount / annual[year].value_scaled("net_income")
                for year, amount in totals.items()
                if annual[year].value_scaled("net_income") > 0
            ]
            if ratios:
                result.payout_median = median(ratios)
                payout_score = _payout_score(result.payout_median)
        else:
            result.reasons.append(
                "payout score=0: нет выплаты, однозначно отнесённой к "
                "финансовому году расчётного окна"
            )
    result.dividends_score = history_score + payout_score
    result.dividends_computed = True
    source_rows = [row for year in completed_calendar_years for row in by_payment_year[year]]
    source_names = " + ".join(sorted({row.source.name for row in source_rows}))
    source_urls = " | ".join(sorted({row.source.url for row in source_rows}))
    result.observations.append(MetricObservation(
        as_of=as_of, issuer_id=result.issuer_id, secid=result.secid,
        metric="paid_years_5", external_source=source_names,
        external_url=source_urls,
        external_period=f"{completed_calendar_years[0]}-{completed_calendar_years[-1]}",
        external_value=result.paid_years_5, unit="years", used_in_score=True,
    ))
    for row in source_rows:
        if row.was_paid and row.amount_per_share is not None:
            result.observations.append(MetricObservation(
                as_of=as_of, issuer_id=result.issuer_id, secid=row.secid,
                metric="dividend_per_share", external_source=row.source.name,
                external_url=row.source.url,
                external_period=(
                    row.payment_date.isoformat()
                    if row.payment_date else str(row.payment_year)
                ),
                external_value=row.amount_per_share, unit=row.currency, used_in_score=True,
            ))
    return None


def _paid_fact_is_known_as_of(row: DividendRecord, as_of: date) -> bool:
    """Не создавать точную дату выплаты, которой нет в официальном источнике.

    Для невыплаты достаточно даты верификации. Факт выплаты с точной датой
    допускается только после неё. Если источник подтверждает лишь календарный
    год/месяц, строка безопасно используется только после завершения года.
    """
    if not row.was_paid:
        return True
    if row.payment_date is not None:
        return row.payment_date <= as_of
    return row.payment_year < as_of.year


def _score_liquidity(
    result: ScoreResult,
    bars: list[MarketBar],
    session_calendar: list[date],
    as_of: date,
    operation_amount: float,
) -> str | None:
    target_dates = set(session_calendar)
    valid = sorted(
        [
            row for row in bars
            if row.trade_date in target_dates and row.value is not None
        ],
        key=lambda x: x.trade_date,
    )[-TARGET_SESSIONS:]
    result.sessions_60 = len(valid)
    if len(valid) < MIN_SESSIONS:
        return f"только {len(valid)} торговых сессий из последних 60; нужно >=55"
    if (as_of - valid[-1].trade_date).days > 5:
        return "рыночные данные старше допустимого разрыва в 3 торговые сессии"
    turnover = median(row.value for row in valid)
    result.turnover_median_60 = turnover
    if turnover < MIN_TURNOVER:
        return "медианный дневной оборот ниже 10 млн рублей"
    if operation_amount > 0.01 * turnover:
        return "размер исследовательской операции выше 1% медианного оборота"
    if turnover < 50_000_000:
        result.liquidity_score = 5
    elif turnover < 250_000_000:
        result.liquidity_score = 10
    else:
        result.liquidity_score = 15
    result.liquidity_computed = True
    result.observations.append(MetricObservation(
        as_of=as_of, issuer_id=result.issuer_id, secid=result.secid,
        metric="turnover_median_60", external_source="MOEX ISS",
        external_url=(
            "https://iss.moex.com/iss/engines/stock/markets/shares/boards/"
            f"TQBR/securities/{result.secid}/candles"
        ), external_period=f"последние {len(valid)} сессий по {valid[-1].trade_date}",
        external_value=turnover, unit="RUB/day", used_in_score=True,
    ))
    return None


def _universe_rejection(instrument: Instrument, as_of: date) -> str | None:
    if instrument.share_class.casefold() not in {
        "common", "preferred", "обыкновенная", "привилегированная"
    }:
        return "тип инструмента не является акцией"
    if instrument.boardid != "TQBR":
        return "бумага не относится к основному режиму TQBR"
    if not instrument.listed_on(as_of):
        return "бумага не была в листинге на дату сигнала"
    if not instrument.iis_available_on(as_of) or instrument.iis_checked_as_of is None:
        return "доступность на ИИС не подтверждена обезличенным allow-list"
    if instrument.iis_checked_as_of > as_of:
        return "allow-list ИИС опубликован после даты сигнала"
    if instrument.financial_sector:
        return "финансовый сектор исключён методологией v0.1"
    if instrument.unresolved_corporate_action:
        return "есть неразрешённое корпоративное событие"
    if not instrument.source.verified or instrument.source.tier not in {"A", "B"}:
        return "идентификатор/сектор не подтверждён надёжным источником"
    if instrument.source.loaded_at is None:
        return "у источника идентификатора/сектора нет времени загрузки"
    return None


def _blocked(
    instrument: Instrument,
    result: ScoreResult,
    reason: str,
    *,
    status: str = "не допущено",
    annual: dict[int, FundamentalRecord] | None = None,
) -> _Prepared:
    result.status = status
    result.total = None
    result.reasons.append(reason)
    return _Prepared(instrument=instrument, result=result, annual=annual or {})


def _debt_score(value: float) -> int:
    if value <= 0:
        return 25
    if value <= 1:
        return 22
    if value <= 2:
        return 15
    if value <= 3:
        return 7
    raise ValueError("Жёсткий фильтр долга должен применяться до начисления балла")


def _payout_score(value: float) -> int:
    if value <= 0:
        return 0
    if value <= 0.75:
        return 10
    if value <= 1.0:
        return 6
    if value <= 1.2:
        return 2
    return 0


def _percentiles(values: dict[str, float | None]) -> dict[str, float]:
    clean = {key: float(value) for key, value in values.items() if value is not None}
    n = len(clean)
    if n < 2:
        return {key: 1.0 for key in clean}
    out = {}
    ordered = list(clean.values())
    for key, value in clean.items():
        less = sum(other < value for other in ordered)
        equal = sum(other == value for other in ordered)
        average_rank = less + (equal + 1) / 2
        out[key] = (average_rank - 1) / (n - 1)
    return out


def _quartile_score(percentile: float) -> int:
    if percentile < 0.25:
        return 0
    if percentile < 0.50:
        return 4
    if percentile < 0.75:
        return 7
    return 10


def _source_summary(records: list[FundamentalRecord]) -> tuple[str, str]:
    names = sorted({row.source.name for row in records})
    urls = sorted({row.source.url for row in records})
    return " + ".join(names), " | ".join(urls)


def _instrument_observations(
    instrument: Instrument, as_of: date
) -> list[MetricObservation]:
    common = dict(
        as_of=as_of, issuer_id=instrument.issuer_id, secid=instrument.secid,
        external_source=instrument.source.name, external_url=instrument.source.url,
        external_period=as_of.isoformat(), unit="category", used_in_score=True,
    )
    return [
        MetricObservation(metric="secid", external_value=instrument.secid, **common),
        MetricObservation(metric="sector", external_value=instrument.sector, **common),
        MetricObservation(
            metric="share_class", external_value=instrument.share_class, **common
        ),
    ]


def _base_observations(
    result: ScoreResult, latest: FundamentalRecord
) -> list[MetricObservation]:
    common = dict(
        as_of=result.as_of, issuer_id=result.issuer_id, secid=result.secid,
        external_source=latest.source.name, external_url=latest.source.url,
        external_period=str(latest.fiscal_year), used_in_score=True,
    )
    return [
        MetricObservation(
            metric="net_debt_ebitda", external_value=result.net_debt_ebitda,
            unit="x", **common,
        ),
        MetricObservation(
            metric="net_income", external_value=latest.value_scaled("net_income"),
            unit=latest.currency, **common,
        ),
        MetricObservation(
            metric="ebitda", external_value=latest.value_scaled("ebitda"),
            unit=latest.currency, **common,
        ),
        MetricObservation(
            metric="fcf", external_value=latest.value_scaled("fcf"),
            unit=latest.currency, **common,
        ),
    ]


def _profitability_observations(
    result: ScoreResult, annual: dict[int, FundamentalRecord]
) -> list[MetricObservation]:
    years = list(range(result.as_of.year - 5, result.as_of.year))
    name, url = _source_summary([annual[year] for year in years])
    common = dict(
        as_of=result.as_of, issuer_id=result.issuer_id, secid=result.secid,
        external_source=f"Собственный расчёт: {name}", external_url=url,
        external_period=f"{years[0]}-{years[-1]}", unit="ratio", used_in_score=True,
    )
    return [
        MetricObservation(metric="roe_5", external_value=result.roe_median_5, **common),
        MetricObservation(
            metric="ebitda_margin_5", external_value=result.margin_median_5, **common
        ),
    ]


def _stability_observations(
    result: ScoreResult, annual: dict[int, FundamentalRecord]
) -> list[MetricObservation]:
    years = list(range(result.as_of.year - 5, result.as_of.year))
    name, url = _source_summary([annual[year] for year in years])
    common = dict(
        as_of=result.as_of, issuer_id=result.issuer_id, secid=result.secid,
        external_source=f"Собственный расчёт: {name}", external_url=url,
        external_period=f"{years[0]}-{years[-1]}", unit="years", used_in_score=True,
    )
    return [
        MetricObservation(
            metric="ni_positive_years", external_value=result.ni_positive_years, **common
        ),
        MetricObservation(
            metric="fcf_positive_years", external_value=result.fcf_positive_years, **common
        ),
        MetricObservation(
            metric="fcf_missing_years", external_value=result.fcf_missing_years, **common
        ),
    ]


def _sort_key(result: ScoreResult):
    if result.total is None:
        return (1, 0, 0, 0, result.secid)
    return (
        0, -result.total, -result.stability_score,
        result.net_debt_ebitda if result.net_debt_ebitda is not None else float("inf"),
        -(result.turnover_median_60 or 0), result.secid,
    )

"""Единственный ретро-прогон v0.1 против MCFTR/MCFTRR.

Движок не подбирает параметры. Если манифест данных не доказывает point-in-time
качество, запуск блокируется до расчёта доходности.
"""
from __future__ import annotations

import hashlib
import json
import math
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from statistics import mean, stdev

from .models import (
    CorporateAction,
    DividendRecord,
    FundamentalRecord,
    IndexPoint,
    Instrument,
    MarketBar,
)
from .portfolio import select_portfolio
from .scoring import score_universe

START_DATE = date(2019, 7, 1)
END_DATE = date(2026, 6, 30)
INITIAL_CAPITAL = 1_000_000.0
BASE_COST = 0.003
STRESS_COST = 0.005


@dataclass(frozen=True)
class DatasetManifest:
    methodology_sha256: str
    point_in_time_verified: bool
    survivorship_bias_controlled: bool
    corporate_actions_complete: bool
    historical_iis_allowlist: bool
    source_archive: str
    frozen_at: str
    notes: str


@dataclass
class Simulation:
    daily_nav: list[tuple[date, float]] = field(default_factory=list)
    selections: list[dict] = field(default_factory=list)
    total_traded: float = 0.0
    total_costs: float = 0.0
    max_issuer_weight: float = 0.0
    max_sector_weight: float = 0.0
    min_issuers: int = 999
    issuer_counts: list[int] = field(default_factory=list)


@dataclass(frozen=True)
class BacktestOutcome:
    status: str
    verdict: str
    blockers: tuple[str, ...]
    metrics: dict[str, float | int | str]
    base: Simulation | None
    stress: Simulation | None
    net: Simulation | None


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_manifest(path: Path) -> DatasetManifest:
    raw = json.loads(path.read_text(encoding="utf-8"))
    required = {
        "methodology_sha256", "point_in_time_verified", "survivorship_bias_controlled",
        "corporate_actions_complete", "historical_iis_allowlist", "source_archive",
        "frozen_at", "notes",
    }
    missing = required - set(raw)
    if missing:
        raise ValueError(f"Манифест не содержит: {', '.join(sorted(missing))}")
    return DatasetManifest(**{key: raw[key] for key in required})


def validate_manifest(manifest: DatasetManifest, methodology_path: Path) -> list[str]:
    blockers = []
    actual_hash = sha256_file(methodology_path)
    if manifest.methodology_sha256.lower() != actual_hash.lower():
        blockers.append(
            f"SHA-256 методологии не совпал: manifest={manifest.methodology_sha256}, actual={actual_hash}"
        )
    checks = {
        "point_in_time_verified": "не подтверждены point-in-time версии отчётности",
        "survivorship_bias_controlled": "не восстановлена историческая вселенная, включая делистинги",
        "corporate_actions_complete": "не подтверждена полнота корпоративных событий",
        "historical_iis_allowlist": "нет исторического обезличенного allow-list ИИС",
    }
    for field_name, message in checks.items():
        if not getattr(manifest, field_name):
            blockers.append(message)
    if not manifest.source_archive.strip():
        blockers.append("в манифесте не указан архив первичных источников")
    return blockers


def run_backtest(
    *,
    manifest: DatasetManifest,
    methodology_path: Path,
    instruments: list[Instrument],
    fundamentals: list[FundamentalRecord],
    dividends: list[DividendRecord],
    market_bars: list[MarketBar],
    mcftr: list[IndexPoint],
    mcftrr: list[IndexPoint],
    corporate_actions: list[CorporateAction],
    dividend_tax_rate: float = 0.13,
) -> BacktestOutcome:
    blockers = validate_manifest(manifest, methodology_path)
    blockers.extend(_coverage_blockers(market_bars, mcftr, mcftrr))
    if blockers:
        return BacktestOutcome(
            status="невалиден по данным",
            verdict="качество данных не позволяет честно проверить правила; положительный вывод запрещён",
            blockers=tuple(blockers), metrics={}, base=None, stress=None, net=None,
        )

    common = dict(
        instruments=instruments, fundamentals=fundamentals, dividends=dividends,
        market_bars=market_bars, calendar=mcftr, corporate_actions=corporate_actions,
    )
    try:
        base = _simulate(cost_rate=BASE_COST, dividend_tax_rate=0.0, **common)
        stress = _simulate(cost_rate=STRESS_COST, dividend_tax_rate=0.0, **common)
        net = _simulate(cost_rate=BASE_COST, dividend_tax_rate=dividend_tax_rate, **common)
    except BacktestDataError as exc:
        return BacktestOutcome(
            status="невалиден по данным",
            verdict="качество данных не позволяет честно проверить правила; положительный вывод запрещён",
            blockers=(str(exc),), metrics={}, base=None, stress=None, net=None,
        )

    metrics = _metrics(base, stress, net, mcftr, mcftrr)
    passed = all([
        metrics["cagr_excess_pp"] >= 2.0,
        metrics["positive_calendar_year_share"] >= 0.60,
        metrics["positive_rolling_3y_share"] >= 2 / 3,
        metrics["portfolio_max_drawdown"] >= metrics["mcftr_max_drawdown"] - 0.10,
        metrics["stress_cagr_excess_pp"] >= 2.0,
        metrics["net_excess_sign"] > 0,
    ])
    verdict = (
        "правила добавляют ценность по заранее утверждённым критериям v0.1"
        if passed else
        "устойчивое преимущество не подтверждено; правила v0.1 не доказали добавленную ценность относительно индекса"
    )
    if not passed:
        verdict += "; индексный фонд лучше правил v0.1 в рамках этого теста"
    return BacktestOutcome(
        status="валидный прогон", verdict=verdict, blockers=(), metrics=metrics,
        base=base, stress=stress, net=net,
    )


class BacktestDataError(RuntimeError):
    pass


def _simulate(
    *,
    cost_rate: float,
    dividend_tax_rate: float,
    instruments: list[Instrument],
    fundamentals: list[FundamentalRecord],
    dividends: list[DividendRecord],
    market_bars: list[MarketBar],
    calendar: list[IndexPoint],
    corporate_actions: list[CorporateAction],
) -> Simulation:
    cal_dates = sorted({row.trade_date for row in calendar if row.secid == "MCFTR"})
    if not cal_dates:
        raise BacktestDataError("нет календаря MCFTR")
    signal_dates = _signal_dates(cal_dates)
    first_signal = min(signal_dates)
    sim_dates = [day for day in cal_dates if first_signal <= day <= END_DATE]
    bars = {(row.trade_date, row.secid): row for row in market_bars}
    bars_by_date: dict[date, list[MarketBar]] = defaultdict(list)
    for row in market_bars:
        bars_by_date[row.trade_date].append(row)
    actions_by_date: dict[date, list[CorporateAction]] = defaultdict(list)
    dividends_by_date: dict[date, list[DividendRecord]] = defaultdict(list)
    for action in corporate_actions:
        if action.action_date < first_signal or action.action_date > END_DATE:
            continue
        event_day = _next_calendar_date(action.action_date, sim_dates)
        actions_by_date[event_day].append(action)
    for row in dividends:
        if (
            row.was_paid and row.payment_date is not None
            and first_signal <= row.payment_date <= END_DATE
        ):
            event_day = _next_calendar_date(row.payment_date, sim_dates)
            dividends_by_date[event_day].append(row)

    holdings: dict[str, float] = {}
    cash = INITIAL_CAPITAL
    last_close: dict[str, float] = {}
    pending: dict[date, tuple] = {}
    result = Simulation()

    for day in sim_dates:
        cash = _apply_actions(day, holdings, cash, actions_by_date.get(day, []))
        for bar in bars_by_date.get(day, []):
            if bar.close is not None:
                last_close[bar.secid] = bar.close

        if day in pending:
            selection, signal_day = pending.pop(day)
            cash, traded, costs = _rebalance(
                day, holdings, cash, selection, bars, last_close, cost_rate
            )
            result.total_traded += traded
            result.total_costs += costs
            result.selections.append({
                "signal_date": signal_day.isoformat(), "execution_date": day.isoformat(),
                "secids": [row.secid for row in selection.selected],
                "formed": selection.formed, "reason": selection.reason,
            })

        for dividend in dividends_by_date.get(day, []):
            shares = holdings.get(dividend.secid, 0.0)
            if shares and dividend.amount_per_share is not None:
                cash += shares * dividend.amount_per_share * (1 - dividend_tax_rate)

        if day in signal_dates:
            nav = _nav(holdings, cash, day, bars, last_close, price_field="close")
            scores = score_universe(
                as_of=day, instruments=instruments, fundamentals=fundamentals,
                dividends=dividends, market_bars=market_bars,
                operation_amount=nav / 12,
            )
            selection = select_portfolio(scores, set(holdings))
            affected = set(holdings) | {row.secid for row in selection.selected}
            execution = _execution_date(day, cal_dates, affected, bars)
            pending[execution] = (selection, day)

        if START_DATE <= day <= END_DATE:
            nav = _nav(holdings, cash, day, bars, last_close, price_field="close")
            result.daily_nav.append((day, nav))
            count = sum(shares > 0 for shares in holdings.values())
            result.issuer_counts.append(count)
            result.min_issuers = min(result.min_issuers, count)
            issuer_weight, sector_weight = _concentration(
                holdings, cash, day, bars, last_close, instruments
            )
            result.max_issuer_weight = max(result.max_issuer_weight, issuer_weight)
            result.max_sector_weight = max(result.max_sector_weight, sector_weight)
    if not result.daily_nav:
        raise BacktestDataError("не сформирован дневной ряд NAV")
    if pending:
        raise BacktestDataError("есть неисполненная ребалансировка на конце периода")
    if result.min_issuers == 999:
        result.min_issuers = 0
    return result


def _next_calendar_date(event_date: date, calendar: list[date]) -> date:
    for day in calendar:
        if day >= event_date:
            return day
    raise BacktestDataError(f"событие {event_date} находится за пределами календаря теста")


def _signal_dates(cal_dates: list[date]) -> set[date]:
    out = set()
    for year in range(START_DATE.year, END_DATE.year):
        june = [day for day in cal_dates if day.year == year and day.month == 6]
        if not june:
            raise BacktestDataError(f"нет торгового календаря за июнь {year}")
        out.add(max(june))
    return out


def _execution_date(
    signal_day: date,
    cal_dates: list[date],
    affected: set[str],
    bars: dict[tuple[date, str], MarketBar],
) -> date:
    candidates = [day for day in cal_dates if day > signal_day][:5]
    for day in candidates:
        if all((bars.get((day, secid)) and bars[(day, secid)].open is not None) for secid in affected):
            return day
    if not affected and candidates:
        return candidates[0]
    raise BacktestDataError(
        f"после {signal_day} нет общей валидной цены OPEN для операций в пределах 5 сессий"
    )


def _rebalance(
    day: date,
    holdings: dict[str, float],
    cash: float,
    selection,
    bars: dict[tuple[date, str], MarketBar],
    last_close: dict[str, float],
    cost_rate: float,
) -> tuple[float, float, float]:
    selected = {row.secid: row for row in selection.selected}
    affected = set(holdings) | set(selected)
    prices = {}
    for secid in affected:
        bar = bars.get((day, secid))
        if not bar or bar.open is None:
            raise BacktestDataError(f"{day} {secid}: нет OPEN для ребалансировки")
        prices[secid] = bar.open
    nav = cash + sum(shares * prices[secid] for secid, shares in holdings.items())

    desired: dict[str, float] = {}
    if selection.formed:
        target = nav * selection.weight_each
        for secid in selected:
            current = holdings.get(secid, 0.0) * prices[secid]
            weight = 0.0 if nav == 0 else current / nav
            desired[secid] = current if secid in holdings and 0.05 <= weight <= 0.10 else target

    sells = []
    buys = []
    for secid in affected:
        current = holdings.get(secid, 0.0) * prices[secid]
        target = desired.get(secid, 0.0)
        if current > target:
            sells.append((secid, current - target))
        elif target > current:
            buys.append((secid, target - current))
    sell_value = sum(value for _, value in sells)
    sell_cost = sell_value * cost_rate
    cash += sell_value - sell_cost
    for secid, value in sells:
        holdings[secid] = max(0.0, holdings.get(secid, 0.0) - value / prices[secid])
        if holdings[secid] < 1e-12:
            holdings.pop(secid, None)

    wanted = sum(value for _, value in buys)
    scale = 0.0 if wanted == 0 else min(1.0, cash / ((1 + cost_rate) * wanted))
    buy_value = wanted * scale
    buy_cost = buy_value * cost_rate
    for secid, value in buys:
        actual = value * scale
        holdings[secid] = holdings.get(secid, 0.0) + actual / prices[secid]
    cash -= buy_value + buy_cost
    if cash < -1e-6:
        raise BacktestDataError("внутренняя ошибка модели: отрицательный денежный остаток")
    return max(cash, 0.0), sell_value + buy_value, sell_cost + buy_cost


def _apply_actions(
    day: date,
    holdings: dict[str, float],
    cash: float,
    actions: list[CorporateAction],
) -> float:
    for action in actions:
        shares = holdings.pop(action.old_secid, 0.0)
        if not shares:
            continue
        if action.cash_per_old_share is not None:
            cash += shares * action.cash_per_old_share
        if action.action_type in {"split", "consolidation"}:
            new_shares = shares * action.share_factor
            target = action.new_secid or action.old_secid
            holdings[target] = holdings.get(target, 0.0) + new_shares
        elif action.action_type in {"ticker_change", "reorganization"} and action.new_secid:
            factor = action.share_factor or 1.0
            holdings[action.new_secid] = holdings.get(action.new_secid, 0.0) + shares * factor
        elif action.action_type == "additional_issue":
            holdings[action.old_secid] = holdings.get(action.old_secid, 0.0) + shares
        elif action.action_type == "delisting" and action.cash_per_old_share is None:
            raise BacktestDataError(f"{day} {action.old_secid}: делистинг без денежного расчёта")
    return cash


def _nav(
    holdings: dict[str, float],
    cash: float,
    day: date,
    bars: dict[tuple[date, str], MarketBar],
    last_close: dict[str, float],
    *,
    price_field: str,
) -> float:
    total = cash
    for secid, shares in holdings.items():
        bar = bars.get((day, secid))
        price = getattr(bar, price_field) if bar else None
        price = price if price is not None else last_close.get(secid)
        if price is None:
            raise BacktestDataError(f"{day} {secid}: нет цены для оценки позиции")
        total += shares * price
    return total


def _concentration(
    holdings: dict[str, float],
    cash: float,
    day: date,
    bars: dict[tuple[date, str], MarketBar],
    last_close: dict[str, float],
    instruments: list[Instrument],
) -> tuple[float, float]:
    nav = _nav(holdings, cash, day, bars, last_close, price_field="close")
    if nav <= 0:
        return 0.0, 0.0
    sector_lookup = {row.secid: row.sector for row in instruments}
    weights = {}
    sectors: dict[str, float] = defaultdict(float)
    for secid, shares in holdings.items():
        bar = bars.get((day, secid))
        price = bar.close if bar and bar.close is not None else last_close[secid]
        weight = shares * price / nav
        weights[secid] = weight
        sectors[sector_lookup.get(secid, "UNKNOWN")] += weight
    return max(weights.values(), default=0.0), max(sectors.values(), default=0.0)


def _coverage_blockers(
    market_bars: list[MarketBar], mcftr: list[IndexPoint], mcftrr: list[IndexPoint]
) -> list[str]:
    blockers = []
    for name, points in (("MCFTR", mcftr), ("MCFTRR", mcftrr)):
        dates = [row.trade_date for row in points if row.secid == name]
        if not dates or min(dates) > START_DATE or max(dates) < END_DATE:
            blockers.append(f"ряд {name} не покрывает {START_DATE}–{END_DATE}")
    bar_dates = [row.trade_date for row in market_bars]
    if not bar_dates or min(bar_dates) > date(2019, 4, 1) or max(bar_dates) < END_DATE:
        blockers.append("рыночные ряды акций не покрывают окно ликвидности и весь период")
    return blockers


def _metrics(
    base: Simulation,
    stress: Simulation,
    net: Simulation,
    mcftr: list[IndexPoint],
    mcftrr: list[IndexPoint],
) -> dict[str, float | int | str]:
    portfolio = dict(base.daily_nav)
    stress_nav = dict(stress.daily_nav)
    net_nav = dict(net.daily_nav)
    gross_index = _normalize_index(mcftr, portfolio)
    net_index = _normalize_index(mcftrr, portfolio)
    common = sorted(set(portfolio) & set(gross_index))
    common_net = sorted(set(net_nav) & set(net_index))
    p = [(day, portfolio[day]) for day in common]
    b = [(day, gross_index[day]) for day in common]
    s = [(day, stress_nav[day]) for day in common if day in stress_nav]
    n = [(day, net_nav[day]) for day in common_net]
    nr = [(day, net_index[day]) for day in common_net]

    p_cagr, b_cagr = _cagr(p), _cagr(b)
    s_cagr = _cagr(s)
    n_cagr, nr_cagr = _cagr(n), _cagr(nr)
    p_monthly, b_monthly = _aligned_monthly_returns(p, b)
    excess = [left - right for left, right in zip(p_monthly, b_monthly)]
    tracking_error = _annualized_std(excess)
    info_ratio = 0.0 if tracking_error == 0 else mean(excess) * 12 / tracking_error
    year_share = _positive_calendar_share(p, b)
    rolling_share = _positive_rolling_share(p, b)
    p_dd, b_dd = _max_drawdown(p), _max_drawdown(b)
    avg_nav = mean(value for _, value in p)
    return {
        "portfolio_cagr": p_cagr,
        "mcftr_cagr": b_cagr,
        "cagr_excess_pp": (p_cagr - b_cagr) * 100,
        "portfolio_volatility": _annualized_std(p_monthly),
        "mcftr_volatility": _annualized_std(b_monthly),
        "portfolio_max_drawdown": p_dd,
        "mcftr_max_drawdown": b_dd,
        "calmar": 0.0 if p_dd == 0 else p_cagr / abs(p_dd),
        "tracking_error": tracking_error,
        "information_ratio": info_ratio,
        "positive_calendar_year_share": year_share,
        "positive_rolling_3y_share": rolling_share,
        "turnover_ratio": 0.0 if avg_nav == 0 else base.total_traded / avg_nav,
        "total_costs_rub": base.total_costs,
        "average_issuers": mean(base.issuer_counts) if base.issuer_counts else 0.0,
        "minimum_issuers": base.min_issuers,
        "max_issuer_weight": base.max_issuer_weight,
        "max_sector_weight": base.max_sector_weight,
        "stress_cagr": s_cagr,
        "stress_cagr_excess_pp": (s_cagr - b_cagr) * 100,
        "net_portfolio_cagr": n_cagr,
        "mcftrr_cagr": nr_cagr,
        "net_excess_sign": 1 if n_cagr - nr_cagr > 0 else (-1 if n_cagr - nr_cagr < 0 else 0),
        "point_in_time_score_share": 1.0,
    }


def _normalize_index(points: list[IndexPoint], reference: dict[date, float]) -> dict[date, float]:
    raw = {row.trade_date: row.close for row in points}
    common = sorted(set(raw) & set(reference))
    if len(common) < 2:
        raise BacktestDataError("недостаточно общих дат портфеля и индекса")
    first = common[0]
    scale = reference[first] / raw[first]
    return {day: raw[day] * scale for day in common}


def _cagr(series: list[tuple[date, float]]) -> float:
    days = (series[-1][0] - series[0][0]).days
    if days <= 0 or series[0][1] <= 0 or series[-1][1] <= 0:
        return 0.0
    return (series[-1][1] / series[0][1]) ** (365.25 / days) - 1


def _month_ends(series: list[tuple[date, float]]) -> list[tuple[date, float]]:
    values = {}
    for day, value in series:
        values[(day.year, day.month)] = (day, value)
    return [values[key] for key in sorted(values)]


def _aligned_monthly_returns(
    left: list[tuple[date, float]], right: list[tuple[date, float]]
) -> tuple[list[float], list[float]]:
    l = {(day.year, day.month): value for day, value in _month_ends(left)}
    r = {(day.year, day.month): value for day, value in _month_ends(right)}
    months = sorted(set(l) & set(r))
    lret, rret = [], []
    for previous, current in zip(months, months[1:]):
        lret.append(l[current] / l[previous] - 1)
        rret.append(r[current] / r[previous] - 1)
    return lret, rret


def _annualized_std(returns: list[float]) -> float:
    return 0.0 if len(returns) < 2 else stdev(returns) * math.sqrt(12)


def _max_drawdown(series: list[tuple[date, float]]) -> float:
    peak = series[0][1]
    worst = 0.0
    for _, value in series:
        peak = max(peak, value)
        worst = min(worst, value / peak - 1)
    return worst


def _positive_calendar_share(
    portfolio: list[tuple[date, float]], benchmark: list[tuple[date, float]]
) -> float:
    p = dict(portfolio)
    b = dict(benchmark)
    common = sorted(set(p) & set(b))
    year_end = {}
    for day in common:
        year_end[day.year] = day
    outcomes = []
    for year in range(START_DATE.year + 1, END_DATE.year):
        if year - 1 in year_end and year in year_end:
            p_ret = p[year_end[year]] / p[year_end[year - 1]] - 1
            b_ret = b[year_end[year]] / b[year_end[year - 1]] - 1
            outcomes.append(p_ret > b_ret)
    return 0.0 if not outcomes else sum(outcomes) / len(outcomes)


def _positive_rolling_share(
    portfolio: list[tuple[date, float]], benchmark: list[tuple[date, float]]
) -> float:
    p = {(d.year, d.month): v for d, v in _month_ends(portfolio)}
    b = {(d.year, d.month): v for d, v in _month_ends(benchmark)}
    months = sorted(set(p) & set(b))
    outcomes = []
    for index in range(36, len(months)):
        old, new = months[index - 36], months[index]
        outcomes.append(p[new] / p[old] > b[new] / b[old])
    return 0.0 if not outcomes else sum(outcomes) / len(outcomes)


def write_retro_markdown(path: Path, outcome: BacktestOutcome, manifest: DatasetManifest) -> Path:
    lines = [
        "# Ретро-отчёт v0.1", "",
        "> Исследование правил качества, не инвестиционная рекомендация и не прогноз доходности.",
        "", f"**Статус:** {outcome.status}", "", f"**Вердикт:** {outcome.verdict}", "",
        "## Фиксация", "",
        f"- SHA-256 методологии: `{manifest.methodology_sha256}`",
        f"- Набор данных заморожен: `{manifest.frozen_at}`",
        f"- Архив источников: {manifest.source_archive or 'не указан'}",
        f"- Период: {START_DATE}–{END_DATE}",
        f"- Издержки: {BASE_COST:.2%} на сторону; стресс {STRESS_COST:.2%}",
    ]
    if outcome.blockers:
        lines.extend(["", "## Блокирующие ограничения данных", ""])
        lines.extend(f"- {item}" for item in outcome.blockers)
    if outcome.metrics:
        lines.extend(["", "## Метрики", "", "| Метрика | Значение |", "| --- | ---: |"])
        for key, value in outcome.metrics.items():
            rendered = f"{value:.6f}" if isinstance(value, float) else str(value)
            lines.append(f"| `{key}` | {rendered} |")
    lines.extend([
        "", "## Дисциплина интерпретации", "",
        "Положительный статус допустим только при одновременном выполнении всех критериев раздела 11.8 методологии. Невалидные point-in-time данные запрещают положительный вывод независимо от рассчитанной доходности.",
    ])
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path

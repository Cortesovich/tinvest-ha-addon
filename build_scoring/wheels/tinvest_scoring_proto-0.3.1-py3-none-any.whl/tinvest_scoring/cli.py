"""CLI прототипа. Все команды — только чтение, расчёт и запись отчётов."""
from __future__ import annotations

import argparse
import json
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from . import __version__
from .backtest import (
    load_manifest,
    run_backtest,
    sha256_file,
    write_retro_markdown,
)
from .crosscheck import (
    compare,
    load_tbank_snapshot,
    write_crosscheck_csv,
    write_crosscheck_markdown,
)
from .csvio import (
    load_corporate_actions,
    load_dividends,
    load_fundamentals,
    load_index_points,
    load_instruments,
    load_market_bars,
    load_metric_observations,
    write_csv,
)
from .reporting import write_observations, write_score_markdown, write_scores
from .scoring import score_universe
from .tma_export import (
    build_tma_payload,
    load_portfolio_snapshot,
    write_generation_log,
    write_tma_json,
)
from .pilot import (
    load_source_registry,
    validate_source_archive,
    write_pilot_audit_markdown,
)
from .market_profile import (
    build_iis_candidate_pool,
    build_market_snapshot,
    load_candidate_secids,
    load_universe,
    recompute_precheck,
    write_coverage_report,
    write_market_snapshot,
    write_precheck,
)

log = logging.getLogger("tinvest_scoring")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="tinvest-scoring",
        description="Read-only рыночный профиль и фундаментальное качество акций МосБиржи",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    parser.add_argument("--verbose", action="store_true")
    sub = parser.add_subparsers(dest="command", required=True)

    download = sub.add_parser("moex-download", help="загрузить публичные данные MOEX ISS")
    download.add_argument("--from", dest="start", type=date.fromisoformat, required=True)
    download.add_argument("--till", dest="end", type=date.fromisoformat, required=True)
    download.add_argument("--secids", default="", help="SECID через запятую")
    download.add_argument("--output-dir", type=Path, required=True)
    download.set_defaults(handler=_cmd_moex_download)

    score = sub.add_parser("score", help="рассчитать топ-N с объяснением каждой строки")
    _add_data_paths(score, include_indexes=False)
    score.add_argument("--as-of", type=date.fromisoformat, required=True)
    score.add_argument("--operation-amount", type=float, required=True)
    score.add_argument("--top", type=int, default=12)
    score.add_argument("--tbank-snapshot", type=Path)
    score.add_argument(
        "--portfolio-snapshot", type=Path,
        help="обезличенный read-only JSON снимка портфеля для TMA fixture",
    )
    score.add_argument(
        "--methodology", type=Path,
        help="утверждённая методология; обязательна вместе с --export-json",
    )
    score.add_argument(
        "--export-json", type=Path,
        help="экспортировать тот же расчёт в контракт представления v0-mock",
    )
    score.add_argument(
        "--export-log", type=Path,
        help="детерминированный лог генерации fixture",
    )
    score.add_argument("--output-dir", type=Path, required=True)
    score.set_defaults(handler=_cmd_score)

    check = sub.add_parser("crosscheck", help="сверить внешний набор с Т-Банком")
    check.add_argument("--external", type=Path, required=True)
    check.add_argument("--tbank-snapshot", type=Path)
    check.add_argument("--output-dir", type=Path, required=True)
    check.set_defaults(handler=_cmd_crosscheck)

    retro = sub.add_parser("retro", help="выполнить единственный ретро-прогон v0.1")
    _add_data_paths(retro, include_indexes=True)
    retro.add_argument("--corporate-actions", type=Path)
    retro.add_argument("--manifest", type=Path, required=True)
    retro.add_argument("--methodology", type=Path, required=True)
    retro.add_argument("--dividend-tax-rate", type=float, default=0.13)
    retro.add_argument("--output", type=Path, required=True)
    retro.set_defaults(handler=_cmd_retro)

    digest = sub.add_parser("methodology-hash", help="показать SHA-256 методологии")
    digest.add_argument("path", type=Path)
    digest.set_defaults(handler=lambda args: _print_hash(args.path))

    pilot = sub.add_parser(
        "pilot-audit", help="проверить доказательный пакет пилотного эмитента"
    )
    pilot.add_argument("--registry", type=Path, required=True)
    pilot.add_argument("--fundamentals", type=Path, required=True)
    pilot.add_argument("--dividends", type=Path, required=True)
    pilot.add_argument("--external", type=Path, required=True)
    pilot.add_argument("--tbank-snapshot", type=Path)
    pilot.add_argument("--output-dir", type=Path, required=True)
    pilot.set_defaults(handler=_cmd_pilot_audit)

    market = sub.add_parser(
        "market-snapshot",
        help="собрать отдельный рыночный профиль v0.3 без торговых действий",
    )
    market.add_argument("--as-of", type=date.fromisoformat, required=True)
    market.add_argument("--precheck", type=Path, required=True)
    market.add_argument("--issuer-map", type=Path, required=True)
    market.add_argument("--moex-securities", type=Path, required=True)
    market.add_argument("--market-bars", type=Path, required=True)
    market.add_argument("--mcftr", type=Path, required=True)
    market.add_argument("--methodology", type=Path, required=True)
    market.add_argument(
        "--quality-snapshot", type=Path,
        help="необязательный фундаментальный снимок; score из рынка не создаётся",
    )
    market.add_argument("--output", type=Path, required=True)
    market.add_argument("--coverage-output", type=Path, required=True)
    market.set_defaults(handler=_cmd_market_snapshot)

    candidates = sub.add_parser(
        "iis-candidates",
        help="собрать обезличенный пул ИИС-акций из read-only снимков Т-Банка",
    )
    candidates.add_argument("--as-of", type=date.fromisoformat, required=True)
    candidates.add_argument("--tbank-universe", type=Path, required=True)
    candidates.add_argument("--allowlist", type=Path, required=True)
    candidates.add_argument("--output", type=Path, required=True)
    candidates.set_defaults(handler=_cmd_iis_candidates)

    refresh = sub.add_parser(
        "market-refresh",
        help="обновить публичные MOEX-данные и атомарно собрать снимок v0.3",
    )
    refresh.add_argument("--as-of", type=date.fromisoformat, required=True)
    refresh.add_argument(
        "--from", dest="start", type=date.fromisoformat,
        help="начало истории; по умолчанию as-of минус три года и 45 дней",
    )
    refresh.add_argument("--base-precheck", type=Path, required=True)
    refresh.add_argument("--methodology", type=Path, required=True)
    refresh.add_argument("--quality-snapshot", type=Path)
    refresh.add_argument("--workers", type=int, default=6)
    refresh.add_argument("--output-dir", type=Path, required=True)
    refresh.set_defaults(handler=_cmd_market_refresh)
    return parser


def _add_data_paths(parser: argparse.ArgumentParser, *, include_indexes: bool) -> None:
    parser.add_argument("--instruments", type=Path, required=True)
    parser.add_argument("--fundamentals", type=Path, required=True)
    parser.add_argument("--dividends", type=Path, required=True)
    parser.add_argument("--market-bars", type=Path, required=True)
    if include_indexes:
        parser.add_argument("--mcftr", type=Path, required=True)
        parser.add_argument("--mcftrr", type=Path, required=True)


def _cmd_moex_download(args) -> int:
    from .moex_iss import MoexIssClient

    if args.end < args.start:
        raise ValueError("--till не может быть раньше --from")
    output = args.output_dir
    output.mkdir(parents=True, exist_ok=True)
    client = MoexIssClient()
    shares = client.current_tqbr_shares()
    write_csv(
        output / "moex_securities_current.csv",
        ["SECID", "SHORTNAME", "ISIN", "LOTSIZE", "CURRENCYID", "LISTLEVEL", "SECTYPE"],
        shares,
    )
    secids = sorted({item.strip().upper() for item in args.secids.split(",") if item.strip()})
    bars = []
    for secid in secids:
        log.info("MOEX candles: %s", secid)
        bars.extend(client.candles(secid, args.start, args.end))
    write_csv(
        output / "market_bars.csv",
        ["secid", "trade_date", "open", "close", "value", "volume"],
        [
            {
                "secid": row.secid, "trade_date": row.trade_date, "open": row.open,
                "close": row.close, "value": row.value, "volume": row.volume,
            }
            for row in bars
        ],
    )
    for index in ("MCFTR", "MCFTRR"):
        points = client.index_history(index, args.start, args.end)
        write_csv(
            output / f"{index.lower()}.csv", ["secid", "trade_date", "close"],
            [
                {"secid": row.secid, "trade_date": row.trade_date, "close": row.close}
                for row in points
            ],
        )
    print(f"MOEX ISS: данные записаны в {output.resolve()}")
    return 0


def _cmd_score(args) -> int:
    if args.export_log and not args.export_json:
        raise ValueError("--export-log применяется только вместе с --export-json")
    if args.export_json and not args.methodology:
        raise ValueError("--export-json требует --methodology")
    instruments = load_instruments(args.instruments)
    fundamentals = load_fundamentals(args.fundamentals)
    dividends = load_dividends(args.dividends)
    market_bars = load_market_bars(args.market_bars)
    results = score_universe(
        as_of=args.as_of,
        instruments=instruments,
        fundamentals=fundamentals,
        dividends=dividends,
        market_bars=market_bars,
        operation_amount=args.operation_amount,
    )
    output = args.output_dir
    scores_path = write_scores(output / "scoring-list.csv", results)
    observations_path = write_observations(output / "metric-observations.csv", results)
    score_md = write_score_markdown(output / "скоринг-отчёт.md", results, args.top)
    external = [obs for row in results for obs in row.observations]
    tbank = load_tbank_snapshot(args.tbank_snapshot) if args.tbank_snapshot else []
    rows = compare(external, tbank)
    write_crosscheck_csv(output / "кросс-чек-отчёт.csv", rows)
    write_crosscheck_markdown(output / "кросс-чек-отчёт.md", rows)

    export_path = None
    export_log_path = None
    if args.export_json:
        portfolio = load_portfolio_snapshot(args.portfolio_snapshot)
        input_paths = {
            "instruments": args.instruments,
            "fundamentals": args.fundamentals,
            "dividends": args.dividends,
            "market_bars": args.market_bars,
        }
        if args.tbank_snapshot:
            input_paths["tbank_snapshot"] = args.tbank_snapshot
        if args.portfolio_snapshot:
            input_paths["portfolio_snapshot"] = args.portfolio_snapshot
        payload = build_tma_payload(
            as_of=args.as_of, results=results, crosschecks=rows,
            methodology_path=args.methodology, input_paths=input_paths,
            source_records=[*instruments, *fundamentals, *dividends],
            portfolio_snapshot=portfolio,
        )
        export_path = write_tma_json(args.export_json, payload)
        export_log_path = args.export_log or args.export_json.with_suffix(".generation.log")
        write_generation_log(
            export_log_path, json_path=export_path, payload=payload,
            command=_canonical_export_command(args, export_log_path),
        )

    ranked = [row for row in results if row.total is not None][:args.top]
    print("Не инвестиционная рекомендация. Прохождение правил v0.1:")
    if not ranked:
        print("  Баллы не рассчитаны: проверьте причины в отчёте.")
    for index, row in enumerate(ranked, 1):
        threshold = "проходит фильтр" if row.passes_score else "не проходит порог 60"
        print(f"{index:>2}. {row.secid:<12} {row.total:>3}/100 — {threshold}: {row.explanation()}")
    print(f"CSV: {scores_path.resolve()}")
    print(f"Метрики: {observations_path.resolve()}")
    print(f"Отчёт: {score_md.resolve()}")
    if export_path:
        print(f"TMA JSON: {export_path.resolve()}")
        print(f"Лог генерации: {export_log_path.resolve()}")
    return 0


def _canonical_export_command(args, export_log_path: Path) -> str:
    """Каноническая воспроизводимая команда для лога и аудита."""
    pairs = [
        ("--as-of", args.as_of.isoformat()),
        ("--operation-amount", str(args.operation_amount)),
        ("--top", str(args.top)),
        ("--instruments", str(args.instruments)),
        ("--fundamentals", str(args.fundamentals)),
        ("--dividends", str(args.dividends)),
        ("--market-bars", str(args.market_bars)),
    ]
    if args.tbank_snapshot:
        pairs.append(("--tbank-snapshot", str(args.tbank_snapshot)))
    if args.portfolio_snapshot:
        pairs.append(("--portfolio-snapshot", str(args.portfolio_snapshot)))
    pairs.extend([
        ("--methodology", str(args.methodology)),
        ("--output-dir", str(args.output_dir)),
        ("--export-json", str(args.export_json)),
        ("--export-log", str(export_log_path)),
    ])
    tokens = [r".\.venv\Scripts\python.exe", "-m", "tinvest_scoring", "score"]
    for flag, value in pairs:
        tokens.extend([flag, value])
    return " ".join(_quote_command_token(token) for token in tokens)


def _quote_command_token(value: str) -> str:
    if not value or any(character.isspace() for character in value):
        return '"' + value.replace('"', '\\"') + '"'
    return value


def _cmd_crosscheck(args) -> int:
    external = load_metric_observations(args.external)
    tbank = load_tbank_snapshot(args.tbank_snapshot) if args.tbank_snapshot else []
    rows = compare(external, tbank)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    csv_path = write_crosscheck_csv(args.output_dir / "кросс-чек-отчёт.csv", rows)
    md_path = write_crosscheck_markdown(args.output_dir / "кросс-чек-отчёт.md", rows)
    print(f"Кросс-чек: {csv_path.resolve()}")
    print(f"Сводка: {md_path.resolve()}")
    return 0


def _cmd_retro(args) -> int:
    manifest = load_manifest(args.manifest)
    actions = load_corporate_actions(args.corporate_actions) if args.corporate_actions else []
    outcome = run_backtest(
        manifest=manifest, methodology_path=args.methodology,
        instruments=load_instruments(args.instruments),
        fundamentals=load_fundamentals(args.fundamentals),
        dividends=load_dividends(args.dividends),
        market_bars=load_market_bars(args.market_bars),
        mcftr=load_index_points(args.mcftr), mcftrr=load_index_points(args.mcftrr),
        corporate_actions=actions, dividend_tax_rate=args.dividend_tax_rate,
    )
    report = write_retro_markdown(args.output, outcome, manifest)
    print(f"Статус: {outcome.status}")
    print(f"Вердикт: {outcome.verdict}")
    print(f"Отчёт: {report.resolve()}")
    return 0 if not outcome.blockers else 2


def _cmd_pilot_audit(args) -> int:
    documents = load_source_registry(args.registry)
    archive_errors = validate_source_archive(args.registry, documents)
    fundamentals = load_fundamentals(args.fundamentals)
    dividends = load_dividends(args.dividends)
    external = load_metric_observations(args.external)
    tbank = load_tbank_snapshot(args.tbank_snapshot) if args.tbank_snapshot else []
    rows = compare(external, tbank)
    output = args.output_dir
    output.mkdir(parents=True, exist_ok=True)
    csv_path = write_crosscheck_csv(output / "кросс-чек-отчёт.csv", rows)
    md_path = write_crosscheck_markdown(output / "кросс-чек-отчёт.md", rows)
    audit_path = write_pilot_audit_markdown(
        output / "аудит.md", documents=documents, archive_errors=archive_errors,
        fundamentals=fundamentals, dividends=dividends, crosscheck_rows=rows,
    )
    print(f"Архив: {'ошибки' if archive_errors else 'проверен'}")
    print("Рейтинг: не рассчитывается — см. шлюз данных в аудите")
    print(f"Кросс-чек: {csv_path.resolve()}")
    print(f"Сводка: {md_path.resolve()}")
    print(f"Аудит: {audit_path.resolve()}")
    return 2 if archive_errors else 0


def _cmd_market_snapshot(args) -> int:
    universe, counts = load_universe(
        args.precheck, args.issuer_map, args.moex_securities, as_of=args.as_of
    )
    input_paths = {
        "issuer_map": args.issuer_map,
        "market_bars": args.market_bars,
        "mcftr": args.mcftr,
        "moex_securities": args.moex_securities,
        "precheck": args.precheck,
    }
    payload = build_market_snapshot(
        as_of=args.as_of,
        universe=universe,
        universe_counts=counts,
        bars=load_market_bars(args.market_bars),
        benchmark=load_index_points(args.mcftr),
        methodology_path=args.methodology,
        input_paths=input_paths,
        quality_snapshot_path=args.quality_snapshot,
    )
    snapshot = write_market_snapshot(args.output, payload)
    coverage = write_coverage_report(args.coverage_output, payload)
    computed = sum(row["market"]["status"] == "computed" for row in payload["rows"])
    print(f"Эмитентов: {len(payload['rows'])}")
    print(f"Рыночный профиль computed: {computed}")
    print(f"JSON: {snapshot.resolve()}")
    print(f"Покрытие: {coverage.resolve()}")
    return 0


def _cmd_iis_candidates(args) -> int:
    rows, counts = build_iis_candidate_pool(
        tbank_universe_path=args.tbank_universe,
        allowlist_path=args.allowlist,
        as_of=args.as_of,
    )
    output = write_precheck(args.output, rows)
    summary_path = args.output.with_suffix(".summary.json")
    summary_path.write_text(
        json.dumps(
            {
                "schema_version": "iis_share_candidates.v0.3",
                "as_of": args.as_of.isoformat(),
                "counts": counts,
                "output_file": args.output.name,
            },
            ensure_ascii=False,
            indent=2,
        ) + "\n",
        encoding="utf-8",
    )
    print(f"ИИС-кандидатов до MOEX/ликвидности: {counts['candidates']}")
    print(f"ISIN-расхождений исключено: {counts['isin_mismatches_excluded']}")
    print(f"CSV: {output.resolve()}")
    print(f"Сводка: {summary_path.resolve()}")
    return 0


def _cmd_market_refresh(args) -> int:
    from .moex_iss import MoexIssClient

    if args.workers < 1 or args.workers > 12:
        raise ValueError("--workers должен быть от 1 до 12")
    start = args.start or (args.as_of - timedelta(days=365 * 3 + 45))
    if start > args.as_of:
        raise ValueError("--from не может быть позже --as-of")

    output = args.output_dir
    raw = output / "raw"
    raw.mkdir(parents=True, exist_ok=True)
    client = MoexIssClient()
    current = client.current_tqbr_shares()
    current_path = write_csv(
        raw / "moex_securities_current.csv",
        ["SECID", "SHORTNAME", "ISIN", "LOTSIZE", "CURRENCYID", "LISTLEVEL", "SECTYPE"],
        current,
    )

    secids = load_candidate_secids(args.base_precheck)
    bars: list = []
    errors: list[dict[str, str]] = []

    def fetch_bars(secid: str):
        worker_client = MoexIssClient(pause_seconds=0.05)
        return worker_client.candles(secid, start, args.as_of)

    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = {pool.submit(fetch_bars, secid): secid for secid in secids}
        for future in as_completed(futures):
            secid = futures[future]
            try:
                result = future.result()
                bars.extend(result)
                log.info("MOEX candles %s: %s", secid, len(result))
            except Exception as exc:
                errors.append({
                    "stage": "candles", "secid": secid,
                    "error": f"{type(exc).__name__}: {exc}",
                })

    indexes = {}
    for index in ("MCFTR", "MCFTRR"):
        try:
            indexes[index] = client.index_history(index, start, args.as_of)
        except Exception as exc:
            errors.append({
                "stage": "index", "secid": index,
                "error": f"{type(exc).__name__}: {exc}",
            })

    if errors:
        error_path = output / "download-errors.json"
        error_path.write_text(
            json.dumps(errors, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        raise RuntimeError(
            f"MOEX refresh не опубликован: ошибок {len(errors)}; см. {error_path}"
        )

    bars.sort(key=lambda row: (row.secid, row.trade_date))
    bars_path = write_csv(
        raw / "market_bars.csv",
        ["secid", "trade_date", "open", "close", "value", "volume"],
        [
            {
                "secid": row.secid, "trade_date": row.trade_date,
                "open": row.open, "close": row.close,
                "value": row.value, "volume": row.volume,
            }
            for row in bars
        ],
    )
    index_paths = {}
    for index, points in indexes.items():
        path = write_csv(
            raw / f"{index.lower()}.csv",
            ["secid", "trade_date", "close"],
            [
                {"secid": row.secid, "trade_date": row.trade_date, "close": row.close}
                for row in points
            ],
        )
        index_paths[index] = path

    refreshed = recompute_precheck(
        base_precheck_path=args.base_precheck,
        current_securities=current,
        bars=bars,
        benchmark=indexes["MCFTR"],
        as_of=args.as_of,
    )
    precheck_path = write_precheck(raw / "universe_precheck.csv", refreshed)
    passing = sorted(
        row["ticker"].upper()
        for row in refreshed
        if row["research_universe_precheck_pass"] == "true"
    )

    identities = []

    def fetch_identity(secid: str):
        worker_client = MoexIssClient(pause_seconds=0)
        return worker_client.security_identity(secid)

    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = {pool.submit(fetch_identity, secid): secid for secid in passing}
        for future in as_completed(futures):
            secid = futures[future]
            try:
                identities.append(future.result())
            except Exception as exc:
                errors.append({
                    "stage": "identity", "secid": secid,
                    "error": f"{type(exc).__name__}: {exc}",
                })
    if errors:
        error_path = output / "download-errors.json"
        error_path.write_text(
            json.dumps(errors, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        raise RuntimeError(
            f"MOEX refresh не опубликован: ошибок {len(errors)}; см. {error_path}"
        )
    retrieved_at = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    identity_path = write_csv(
        raw / "moex_issuer_map.csv",
        [
            "secid", "shortname", "isin", "emitent_id", "emitent_title",
            "emitent_inn", "identity_status", "identity_error", "retrieved_at",
            "source_url",
        ],
        [{**row, "retrieved_at": retrieved_at} for row in sorted(
            identities, key=lambda item: item["secid"]
        )],
    )

    universe, counts = load_universe(
        precheck_path, identity_path, current_path, as_of=args.as_of
    )
    input_paths = {
        "base_precheck": args.base_precheck,
        "issuer_map": identity_path,
        "market_bars": bars_path,
        "mcftr": index_paths["MCFTR"],
        "mcftrr": index_paths["MCFTRR"],
        "moex_securities": current_path,
        "precheck": precheck_path,
    }
    payload = build_market_snapshot(
        as_of=args.as_of,
        universe=universe,
        universe_counts=counts,
        bars=bars,
        benchmark=indexes["MCFTR"],
        methodology_path=args.methodology,
        input_paths=input_paths,
        quality_snapshot_path=args.quality_snapshot,
    )
    snapshot = write_market_snapshot(output / "scoring_snapshot_v03.json", payload)
    coverage = write_coverage_report(output / "покрытие-v0.3.md", payload)
    stale_error_path = output / "download-errors.json"
    if stale_error_path.exists():
        stale_error_path.unlink()
    print(f"Кандидатов до ликвидности: {len(secids)}")
    print(f"Прошедших классов: {len(passing)}")
    print(f"Эмитентов после дедупликации: {len(universe)}")
    print(f"JSON: {snapshot.resolve()}")
    print(f"Покрытие: {coverage.resolve()}")
    return 0


def _print_hash(path: Path) -> int:
    print(sha256_file(path))
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    try:
        return int(args.handler(args) or 0)
    except (ValueError, OSError, RuntimeError) as exc:
        parser.exit(2, f"Ошибка: {exc}\n")

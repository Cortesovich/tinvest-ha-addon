"""Детерминированные правила состава исследовательского портфеля."""
from __future__ import annotations

from dataclasses import dataclass
from math import floor

from .models import ScoreResult


@dataclass(frozen=True)
class PortfolioSelection:
    selected: tuple[ScoreResult, ...]
    weight_each: float
    formed: bool
    reason: str


def select_portfolio(
    results: list[ScoreResult], existing_secids: set[str] | None = None
) -> PortfolioSelection:
    """Выбрать 12, 11 либо 10 эмитентов с лимитом сектора 25%.

    Для уже находившейся бумаги применяется буфер 50 баллов / место не ниже
    18-го. Новая бумага требует 60 баллов. При невозможности сформировать хотя
    бы 10 позиций возвращается денежный остаток (пустой состав).
    """
    existing_secids = existing_secids or set()
    ranked = [row for row in results if row.status == "допущено" and row.total is not None]
    rank = {row.secid: index + 1 for index, row in enumerate(ranked)}
    retained = [
        row for row in ranked
        if row.secid in existing_secids and row.total >= 50 and rank[row.secid] <= 18
    ]
    newcomers = [row for row in ranked if row.total >= 60 and row.secid not in existing_secids]

    for target in (12, 11, 10):
        per_sector = floor(0.25 * target + 1e-12)
        selected: list[ScoreResult] = []
        counts: dict[str, int] = {}
        for row in [*retained, *newcomers]:
            if len(selected) >= target:
                break
            if any(old.issuer_id == row.issuer_id for old in selected):
                continue
            if counts.get(row.sector, 0) >= per_sector:
                continue
            selected.append(row)
            counts[row.sector] = counts.get(row.sector, 0) + 1
        if len(selected) == target:
            return PortfolioSelection(
                selected=tuple(selected), weight_each=1.0 / target, formed=True,
                reason=f"сформировано {target} позиций по правилам v0.1",
            )
    return PortfolioSelection(
        selected=(), weight_each=0.0, formed=False,
        reason="после фильтров и секторного лимита осталось менее 10 эмитентов",
    )


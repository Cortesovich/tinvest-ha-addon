"""Read-only загрузчик публичного MOEX ISS.

Модуль выполняет только HTTPS GET к ``iss.moex.com``. В нём намеренно нет
брокерской авторизации, счетов и методов выставления заявок.
"""
from __future__ import annotations

import logging
import json
import http.client
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import date, datetime
from typing import Any, Iterator

from .models import IndexPoint, MarketBar

log = logging.getLogger("moex_iss")

BASE_URL = "https://iss.moex.com/iss"
USER_AGENT = "tinvest-scoring-proto/0.3 read-only market profile"


class MoexIssError(RuntimeError):
    pass


class MoexIssClient:
    def __init__(self, *, timeout: int = 30, pause_seconds: float = 0.05):
        self.timeout = timeout
        self.pause_seconds = pause_seconds
        self.headers = {"User-Agent": USER_AGENT, "Accept": "application/json"}

    def _get(self, path: str, params: dict[str, Any]) -> dict:
        if not path.startswith("/") or "://" in path:
            raise MoexIssError("Разрешены только относительные пути MOEX ISS")
        last_error: Exception | None = None
        for attempt in range(3):
            try:
                query = urllib.parse.urlencode(params)
                request = urllib.request.Request(
                    f"{BASE_URL + path}?{query}", headers=self.headers
                )
                with urllib.request.urlopen(request, timeout=self.timeout) as response:
                    payload = json.load(response)
                if not isinstance(payload, dict):
                    raise MoexIssError("MOEX ISS вернул неожиданный JSON")
                return payload
            except (
                urllib.error.URLError,
                TimeoutError,
                OSError,
                http.client.HTTPException,
                ValueError,
                json.JSONDecodeError,
            ) as exc:
                last_error = exc
                if attempt < 2:
                    time.sleep(0.5 * (2 ** attempt))
        raise MoexIssError(f"MOEX ISS недоступен: {last_error}") from last_error

    @staticmethod
    def _block(payload: dict, block: str) -> list[dict[str, Any]]:
        raw = payload.get(block) or {}
        columns = raw.get("columns") or []
        data = raw.get("data") or []
        if not isinstance(columns, list) or not isinstance(data, list):
            raise MoexIssError(f"Некорректный блок ISS: {block}")
        return [dict(zip(columns, row, strict=False)) for row in data]

    def _pages(
        self, path: str, block: str, params: dict[str, Any], *, page_size: int = 100
    ) -> Iterator[dict[str, Any]]:
        start = 0
        while True:
            page_params = {**params, "start": start, "iss.meta": "off"}
            payload = self._get(path, page_params)
            rows = self._block(payload, block)
            yield from rows
            if not rows:
                break
            cursor = self._block(payload, f"{block}.cursor")
            if cursor:
                total = int(cursor[0].get("TOTAL") or 0)
                actual_size = int(cursor[0].get("PAGESIZE") or len(rows))
                start += actual_size
                if start >= total:
                    break
            else:
                start += len(rows)
                if len(rows) < page_size:
                    break
            if self.pause_seconds:
                time.sleep(self.pause_seconds)

    def current_tqbr_shares(self) -> list[dict[str, Any]]:
        """Текущие инструменты TQBR; историческую вселенную этот метод не обещает."""
        payload = self._get(
            "/engines/stock/markets/shares/boards/TQBR/securities.json",
            {
                "iss.only": "securities",
                "iss.meta": "off",
                "securities.columns": (
                    "SECID,SHORTNAME,ISIN,LOTSIZE,CURRENCYID,LISTLEVEL,SECTYPE"
                ),
            },
        )
        rows = self._block(payload, "securities")
        return [row for row in rows if str(row.get("SECTYPE")) in {"1", "2"}]

    def security_identity(self, secid: str, isin: str = "") -> dict[str, Any]:
        """Связать SECID/ISIN с emitent_id без сопоставления по названию."""
        safe_secid = _identifier(secid)
        normalized_isin = isin.strip().upper()
        query_value = normalized_isin or safe_secid
        params = {
            "iss.only": "securities",
            "iss.meta": "off",
            "securities.columns": (
                "secid,shortname,isin,emitent_id,emitent_title,emitent_inn"
            ),
            "q": query_value,
            "limit": 100,
        }
        payload = self._get("/securities.json", params)
        matches = [
            row for row in self._block(payload, "securities")
            if str(row.get("secid", "")).upper() == safe_secid
            and (
                not normalized_isin
                or str(row.get("isin", "")).upper() == normalized_isin
            )
        ]
        source_url = f"{BASE_URL}/securities.json?{urllib.parse.urlencode(params)}"
        if len(matches) != 1:
            return {
                "secid": safe_secid,
                "isin": normalized_isin,
                "emitent_id": "",
                "emitent_title": "",
                "emitent_inn": "",
                "identity_status": "not_unique_or_missing",
                "identity_error": f"exact_matches={len(matches)}",
                "source_url": source_url,
            }
        row = {
            key: "" if value is None else value for key, value in matches[0].items()
        }
        row.update(
            {
                "identity_status": "matched",
                "identity_error": "",
                "source_url": source_url,
            }
        )
        return row

    def candles(
        self, secid: str, start_date: date, end_date: date, *, boardid: str = "TQBR"
    ) -> list[MarketBar]:
        safe_secid = _identifier(secid)
        safe_board = _identifier(boardid)
        path = (
            f"/engines/stock/markets/shares/boards/{safe_board}/"
            f"securities/{safe_secid}/candles.json"
        )
        params = {
            "from": start_date.isoformat(), "till": end_date.isoformat(),
            "interval": 24,
            "candles.columns": "open,close,value,volume,begin",
        }
        out = []
        for row in self._pages(path, "candles", params, page_size=500):
            out.append(MarketBar(
                secid=safe_secid,
                trade_date=datetime.fromisoformat(row["begin"]).date(),
                open=_optional_float(row.get("open")), close=_optional_float(row.get("close")),
                value=_optional_float(row.get("value")),
                volume=_optional_float(row.get("volume")),
            ))
        return out

    def index_history(
        self, secid: str, start_date: date, end_date: date
    ) -> list[IndexPoint]:
        safe_secid = _identifier(secid)
        path = f"/history/engines/stock/markets/index/securities/{safe_secid}.json"
        params = {
            "from": start_date.isoformat(), "till": end_date.isoformat(),
            "history.columns": "SECID,TRADEDATE,CLOSE",
        }
        out = []
        for row in self._pages(path, "history", params):
            if row.get("CLOSE") is None:
                continue
            out.append(IndexPoint(
                secid=safe_secid, trade_date=date.fromisoformat(row["TRADEDATE"]),
                close=float(row["CLOSE"]),
            ))
        return out


def _identifier(value: str) -> str:
    normalized = value.strip().upper()
    if not normalized or any(ch not in "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-" for ch in normalized):
        raise MoexIssError(f"Недопустимый идентификатор ISS: {value!r}")
    return normalized


def _optional_float(value) -> float | None:
    return None if value is None else float(value)

"""Детерминированный экспорт результата скоринга в контракт TMA v0-mock.

Это формат представления read-only мока, а не API торгового бота. Модуль не
содержит командных, торговых или целевых ценовых полей.
"""
from __future__ import annotations

import json
from collections import Counter
from datetime import date, datetime, time, timezone
from hashlib import sha256
from math import isfinite
from pathlib import Path
from typing import Any, Iterable

from . import __version__
from .backtest import sha256_file
from .models import (
    CrosscheckRow,
    CrosscheckStatus,
    DividendRecord,
    FundamentalRecord,
    Instrument,
    MetricObservation,
    ScoreResult,
)


CONTRACT_VERSION = "v0-mock.2"
METHODOLOGY_VERSION = "0.1"
MIN_SECTOR_ISSUERS = 5
ROW_STATUSES = {"computed", "blocked", "insufficient_data"}
COMPONENTS = (
    ("debt", "Долг", 25),
    ("profitability", "Рентабельность", 20),
    ("stability", "Стабильность", 20),
    ("dividends", "Дивиденды", 20),
    ("liquidity", "Ликвидность", 15),
)


def load_portfolio_snapshot(path: Path | None) -> dict[str, Any] | None:
    """Прочитать обезличенный read-only снимок портфеля для fixture."""
    if path is None:
        return None
    try:
        raw = json.loads(path.read_text(encoding="utf-8-sig"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"{path}: некорректный JSON: {exc}") from exc
    if not isinstance(raw, dict):
        raise ValueError(f"{path}: корнем снимка портфеля должен быть объект")
    legacy_keys = {"as_of", "currency", "cash_value", "positions", "payments", "source"}
    schema_version = raw.get("schema_version", "portfolio_snapshot.v1")
    if schema_version not in {"portfolio_snapshot.v1", "portfolio_snapshot.v2"}:
        raise ValueError(f"{path}: неизвестная schema_version")
    allowed = legacy_keys if schema_version == "portfolio_snapshot.v1" else {
        *legacy_keys, "schema_version", "performance",
    }
    _reject_unknown(raw, allowed, path)
    required = legacy_keys if schema_version == "portfolio_snapshot.v1" else allowed
    _require_keys(raw, required, path)
    _parse_utc(raw["as_of"], f"{path}: as_of")
    currency = raw["currency"]
    if not isinstance(currency, str) or len(currency) != 3 or not currency.isalpha():
        raise ValueError(f"{path}: currency должен быть трёхбуквенным кодом")
    _nonnegative_number(raw["cash_value"], f"{path}: cash_value")
    if not isinstance(raw["positions"], list) or not isinstance(raw["payments"], list):
        raise ValueError(f"{path}: positions и payments должны быть массивами")
    source = raw["source"]
    if not isinstance(source, dict):
        raise ValueError(f"{path}: source должен быть объектом")
    _reject_unknown(source, {"kind", "description", "loaded_at"}, path)
    _require_keys(source, {"kind", "description", "loaded_at"}, path)
    _parse_utc(source["loaded_at"], f"{path}: source.loaded_at")
    for index, item in enumerate(raw["positions"]):
        label = f"{path}: positions[{index}]"
        if not isinstance(item, dict):
            raise ValueError(f"{label} должен быть объектом")
        position_keys = {"instrument_type", "secid", "name", "quantity", "market_value"}
        if schema_version == "portfolio_snapshot.v2":
            position_keys |= {"issuer_name", "unit_price", "coupon_rate"}
        _reject_unknown(item, position_keys, path)
        _require_keys(item, position_keys, path)
        _nonnegative_number(item["quantity"], f"{label}.quantity")
        _nonnegative_number(item["market_value"], f"{label}.market_value")
        if schema_version == "portfolio_snapshot.v2":
            if item["issuer_name"] is not None and not isinstance(item["issuer_name"], str):
                raise ValueError(f"{label}.issuer_name: требуется строка или null")
            _nullable_nonnegative_number(item["unit_price"], f"{label}.unit_price")
            _nullable_nonnegative_number(item["coupon_rate"], f"{label}.coupon_rate")
    for index, item in enumerate(raw["payments"]):
        label = f"{path}: payments[{index}]"
        if not isinstance(item, dict):
            raise ValueError(f"{label} должен быть объектом")
        allowed = {"payment_at", "kind", "secid", "name", "amount", "currency"}
        _reject_unknown(item, allowed, path)
        _require_keys(item, allowed, path)
        _parse_utc(item["payment_at"], f"{label}.payment_at")
        _nonnegative_number(item["amount"], f"{label}.amount")
    if schema_version == "portfolio_snapshot.v2" and raw["performance"] is not None:
        performance = raw["performance"]
        if not isinstance(performance, dict):
            raise ValueError(f"{path}: performance должен быть объектом или null")
        performance_keys = {
            "annualized_return", "as_of", "calculated_from", "coupons", "currency",
            "method", "net_contributions", "profit", "tax_deductions",
        }
        _reject_unknown(performance, performance_keys, path)
        _require_keys(performance, performance_keys, path)
        if performance["method"] != "xirr":
            raise ValueError(f"{path}: performance.method должен быть xirr")
        if performance["currency"] != raw["currency"].upper():
            raise ValueError(f"{path}: performance.currency должен совпадать с currency")
        if _utc_text(performance["as_of"]) != _utc_text(raw["as_of"]):
            raise ValueError(f"{path}: performance.as_of должен совпадать с as_of")
        if _parse_utc(performance["calculated_from"], f"{path}: performance.calculated_from") > _parse_utc(raw["as_of"], f"{path}: as_of"):
            raise ValueError(f"{path}: performance.calculated_from позже as_of")
        _finite_number(performance["annualized_return"], f"{path}: performance.annualized_return")
        _nullable_finite_number(performance["net_contributions"], f"{path}: performance.net_contributions")
        _nullable_finite_number(performance["profit"], f"{path}: performance.profit")
        _nullable_nonnegative_number(performance["coupons"], f"{path}: performance.coupons")
        _nullable_nonnegative_number(performance["tax_deductions"], f"{path}: performance.tax_deductions")
    return raw


def build_tma_payload(
    *,
    as_of: date,
    results: list[ScoreResult],
    crosschecks: list[CrosscheckRow],
    methodology_path: Path,
    input_paths: dict[str, Path],
    source_records: Iterable[Instrument | FundamentalRecord | DividendRecord],
    portfolio_snapshot: dict[str, Any] | None,
) -> dict[str, Any]:
    """Собрать JSON-совместимый объект только из результатов расчёта."""
    observation_count = sum(len(item.observations) for item in results)
    if observation_count != len(crosschecks):
        raise ValueError(
            "Экспорт ожидает один кросс-чек на каждое наблюдение: "
            f"наблюдений {observation_count}, строк кросс-чека {len(crosschecks)}"
        )
    generated_at = _generated_at(as_of, source_records, portfolio_snapshot)
    hashes = {key: sha256_file(path) for key, path in sorted(input_paths.items())}
    checks_cursor = 0
    computed_rank = 0
    rows = []
    for result in results:
        item_checks = crosschecks[checks_cursor:checks_cursor + len(result.observations)]
        checks_cursor += len(result.observations)
        for observation, check in zip(result.observations, item_checks):
            _validate_crosscheck_pair(observation, check)
        if result.total is not None:
            computed_rank += 1
            rank: int | None = computed_rank
        else:
            rank = None
        rows.append(_serialize_score_row(result, rank, item_checks))

    sector_counts = Counter(item.sector for item in results if item.sector_candidate)
    sectors = sorted({item.sector for item in results})
    sector_gates = []
    for sector in sectors:
        valid = sector_counts[sector]
        formed = valid >= MIN_SECTOR_ISSUERS
        sector_gates.append({
            "sector": sector,
            "valid_issuers": valid,
            "required_issuers": MIN_SECTOR_ISSUERS,
            "status": "formed" if formed else "not_formed",
            "message": (
                f"Валидных эмитентов: {valid} из необходимых {MIN_SECTOR_ISSUERS}; "
                + ("секторный рейтинг сформирован." if formed else "секторный рейтинг не сформирован.")
            ),
        })

    return {
        "contract_version": CONTRACT_VERSION,
        "methodology_version": METHODOLOGY_VERSION,
        "methodology_sha256": sha256_file(methodology_path),
        "generated_at": generated_at,
        "as_of": _date_utc(as_of),
        "disclaimer": "Не является инвестиционной рекомендацией.",
        "provenance": {
            "purpose": "static_mock_output",
            "producer": "tinvest_scoring",
            "module_version": __version__,
            "network_access": False,
            "input_sha256": hashes,
        },
        "portfolio": _serialize_portfolio(portfolio_snapshot),
        "scoring": {
            "score_scale": {"minimum": 0, "maximum": 100},
            "sector_gates": sector_gates,
            "rows": rows,
        },
    }


def write_tma_json(path: Path, payload: dict[str, Any]) -> Path:
    """Записать канонический UTF-8 JSON; одинаковый payload даёт те же байты."""
    encoded = _json_bytes(payload)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(encoded)
    return path


def write_generation_log(
    path: Path,
    *,
    json_path: Path,
    payload: dict[str, Any],
    command: str,
) -> Path:
    """Записать проверяемый лог без текущего времени и другой недетерминированности."""
    json_digest = sha256(json_path.read_bytes()).hexdigest()
    lines = [
        "status=OK",
        f"contract_version={payload['contract_version']}",
        f"methodology_version={payload['methodology_version']}",
        f"generated_at={payload['generated_at']}",
        f"json_sha256={json_digest}",
        f"json_bytes={json_path.stat().st_size}",
        f"command={command}",
    ]
    for key, digest in sorted(payload["provenance"]["input_sha256"].items()):
        lines.append(f"input_sha256.{key}={digest}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    return path


def _serialize_score_row(
    result: ScoreResult,
    rank: int | None,
    crosschecks: list[CrosscheckRow],
) -> dict[str, Any]:
    status = _row_status(result)
    if status not in ROW_STATUSES:
        raise ValueError(f"Неизвестный машинный статус строки: {status}")
    counts = Counter(_crosscheck_status(item.status) for item in crosschecks)
    aggregate = {
        "matched": counts["matched"],
        "mismatched": counts["mismatched"],
        "not_checked": counts["not_checked"],
    }
    if aggregate["mismatched"]:
        summary = "mismatched"
    elif aggregate["not_checked"] or not crosschecks:
        summary = "not_checked"
    else:
        summary = "matched"
    return {
        "issuer_id": result.issuer_id,
        "secid": result.secid,
        "name": result.name,
        "sector": result.sector,
        "as_of": _date_utc(result.as_of),
        "status": status,
        "score": result.total,
        "rank": rank,
        "passes_filter": result.passes_score if result.total is not None else None,
        "sector_candidate": result.sector_candidate,
        "components": {
            key: _component(result, key, label, maximum)
            for key, label, maximum in COMPONENTS
        },
        "indicators": {
            "net_debt_ebitda": result.net_debt_ebitda,
            "roe_median_5": result.roe_median_5,
            "ebitda_margin_median_5": result.margin_median_5,
            "net_income_positive_years": result.ni_positive_years,
            "fcf_positive_years": result.fcf_positive_years,
            "fcf_missing_years": result.fcf_missing_years,
            "dividend_paid_years_5": result.paid_years_5,
            "payout_median": result.payout_median,
            "turnover_median_60": result.turnover_median_60,
            "market_sessions_60": result.sessions_60,
        },
        "crosscheck": {"summary_status": summary, **aggregate},
        "reasons": list(result.reasons),
        "explanation": result.explanation(),
        "metrics": [
            _serialize_metric(observation, check)
            for observation, check in zip(result.observations, crosschecks)
        ],
    }


def _serialize_metric(observation: MetricObservation, check: CrosscheckRow) -> dict[str, Any]:
    return {
        "key": observation.metric,
        "value": observation.external_value,
        "unit": observation.unit,
        "period": observation.external_period,
        "used_in_score": observation.used_in_score,
        "source": {
            "name": observation.external_source,
            "url": observation.external_url,
        },
        "crosscheck": {
            "status": _crosscheck_status(check.status),
            "tbank_period": check.tbank_period or None,
            "tbank_value": check.tbank_value,
            "absolute_difference": check.abs_diff,
            "relative_difference_pct": check.rel_diff_pct,
            "tolerance": check.tolerance,
            "note": check.exclusion_reason or None,
        },
    }


def _serialize_portfolio(snapshot: dict[str, Any] | None) -> dict[str, Any]:
    if snapshot is None:
        return {
            "status": "not_connected",
            "as_of": None,
            "currency": None,
            "total_value": None,
            "cash": {"value": None, "weight": None},
            "ingest_received_at": None,
            "performance": None,
            "positions": [],
            "upcoming_payments": [],
            "source": None,
        }
    cash = float(snapshot["cash_value"])
    position_total = sum(float(item["market_value"]) for item in snapshot["positions"])
    total = cash + position_total

    def weight(value: float) -> float | None:
        return None if total == 0 else value / total

    positions = []
    for item in snapshot["positions"]:
        market_value = float(item["market_value"])
        positions.append({
            "instrument_type": item["instrument_type"],
            "secid": item["secid"],
            "name": item["name"],
            "quantity": item["quantity"],
            "market_value": market_value,
            "issuer_name": item.get("issuer_name"),
            "unit_price": item.get("unit_price"),
            "coupon_rate": item.get("coupon_rate"),
            "weight": weight(market_value),
        })
    payments = [
        {
            "payment_at": _utc_text(item["payment_at"]),
            "kind": item["kind"],
            "secid": item["secid"],
            "name": item["name"],
            "amount": float(item["amount"]),
            "currency": item["currency"],
        }
        for item in sorted(snapshot["payments"], key=lambda row: (row["payment_at"], row["secid"]))
    ]
    performance = snapshot.get("performance")
    serialized_performance = None if performance is None else {
        "annualized_return": performance["annualized_return"],
        "as_of": _utc_text(performance["as_of"]),
        "calculated_from": _utc_text(performance["calculated_from"]),
        "coupons": performance["coupons"],
        "currency": performance["currency"],
        "method": performance["method"],
        "net_contributions": performance["net_contributions"],
        "profit": performance["profit"],
        "tax_deductions": performance["tax_deductions"],
    }
    return {
        "status": "available",
        "as_of": _utc_text(snapshot["as_of"]),
        "currency": snapshot["currency"].upper(),
        "total_value": total,
        "cash": {"value": cash, "weight": weight(cash)},
        "ingest_received_at": None,
        "performance": serialized_performance,
        "positions": positions,
        "upcoming_payments": payments,
        "source": {
            "kind": snapshot["source"]["kind"],
            "description": snapshot["source"]["description"],
            "loaded_at": _utc_text(snapshot["source"]["loaded_at"]),
        },
    }


def _component(result: ScoreResult, key: str, label: str, maximum: int) -> dict[str, Any]:
    computed = bool(getattr(result, f"{key}_computed"))
    return {
        "label": label,
        "status": "computed" if computed else "not_computed",
        "score": getattr(result, f"{key}_score") if computed else None,
        "maximum": maximum,
    }


def _row_status(result: ScoreResult) -> str:
    if result.total is not None:
        return "computed"
    if result.status == "данных недостаточно":
        return "insufficient_data"
    return "blocked"


def _crosscheck_status(status: CrosscheckStatus) -> str:
    return {
        CrosscheckStatus.MATCHED: "matched",
        CrosscheckStatus.MISMATCHED: "mismatched",
        CrosscheckStatus.NOT_CHECKED: "not_checked",
    }[status]


def _validate_crosscheck_pair(observation: MetricObservation, check: CrosscheckRow) -> None:
    left = (
        observation.as_of, observation.issuer_id, observation.secid,
        observation.metric, observation.external_source, observation.external_url,
        observation.external_period,
    )
    right = (
        check.as_of, check.issuer_id, check.secid, check.metric,
        check.external_source, check.external_url, check.external_period,
    )
    if left != right:
        raise ValueError("Порядок кросс-чека не соответствует порядку наблюдений скоринга")


def _generated_at(
    as_of: date,
    records: Iterable[Instrument | FundamentalRecord | DividendRecord],
    portfolio_snapshot: dict[str, Any] | None,
) -> str:
    timestamps = []
    for record in records:
        loaded_at = record.source.loaded_at
        if loaded_at is not None:
            if loaded_at.tzinfo is None or loaded_at.utcoffset() is None:
                raise ValueError("source.loaded_at обязан содержать явный часовой пояс")
            timestamps.append(loaded_at.astimezone(timezone.utc))
    if portfolio_snapshot is not None:
        timestamps.append(_parse_utc(portfolio_snapshot["source"]["loaded_at"], "source.loaded_at"))
    fallback = datetime.combine(as_of, time.min, tzinfo=timezone.utc)
    return _format_utc(max(timestamps, default=fallback))


def _date_utc(value: date) -> str:
    return _format_utc(datetime.combine(value, time.min, tzinfo=timezone.utc))


def _utc_text(value: str) -> str:
    return _format_utc(_parse_utc(value, "timestamp"))


def _parse_utc(value: Any, label: str) -> datetime:
    if not isinstance(value, str):
        raise ValueError(f"{label}: нужен ISO-8601 timestamp с явным UTC")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(f"{label}: нужен ISO-8601 timestamp с явным UTC") from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError(f"{label}: часовой пояс обязателен")
    if parsed.utcoffset().total_seconds() != 0:
        raise ValueError(f"{label}: требуется явный UTC, получено смещение {parsed.utcoffset()}")
    return parsed.astimezone(timezone.utc)


def _format_utc(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _json_bytes(payload: dict[str, Any]) -> bytes:
    text = json.dumps(
        payload, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False,
    ) + "\n"
    return text.encode("utf-8")


def _require_keys(value: dict[str, Any], required: set[str], path: Path) -> None:
    missing = required - set(value)
    if missing:
        raise ValueError(f"{path}: отсутствуют поля: {', '.join(sorted(missing))}")


def _reject_unknown(value: dict[str, Any], allowed: set[str], path: Path) -> None:
    unknown = set(value) - allowed
    if unknown:
        raise ValueError(f"{path}: неизвестные/зарезервированные поля: {', '.join(sorted(unknown))}")


def _nonnegative_number(value: Any, label: str) -> None:
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or not isfinite(value)
        or value < 0
    ):
        raise ValueError(f"{label}: требуется неотрицательное число")


def _finite_number(value: Any, label: str) -> None:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(value):
        raise ValueError(f"{label}: требуется конечное число")


def _nullable_nonnegative_number(value: Any, label: str) -> None:
    if value is not None:
        _nonnegative_number(value, label)


def _nullable_finite_number(value: Any, label: str) -> None:
    if value is not None:
        _finite_number(value, label)

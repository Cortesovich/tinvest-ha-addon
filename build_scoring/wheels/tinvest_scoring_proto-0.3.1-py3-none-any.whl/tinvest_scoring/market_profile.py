"""Автоматический read-only рыночный профиль v0.3.

Модуль не рассчитывает прогноз цены и не выставляет заявки. Рыночные поля
хранятся отдельно от фундаментального качества и не могут заполнить его score.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
import statistics
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable

from .models import IndexPoint, MarketBar


SCHEMA_VERSION = "scoring_snapshot.v0.3"
METHODOLOGY_VERSION = "0.3"
MIN_SESSIONS_60 = 55
MIN_MEDIAN_TURNOVER_RUB = 10_000_000.0

SECTOR_NAMES = {
    "consumer": "Потребительский сектор",
    "energy": "Нефтегаз",
    "financial": "Финансы",
    "health_care": "Здравоохранение",
    "industrials": "Промышленность и транспорт",
    "it": "Технологии",
    "materials": "Материалы",
    "real_estate": "Недвижимость",
    "telecom": "Телеком",
    "utilities": "Электроэнергетика",
}


class MarketProfileContractError(ValueError):
    """Входы v0.3 нельзя однозначно объединить."""


@dataclass(frozen=True)
class UniverseSecurity:
    issuer_id: str
    secid: str
    isin: str
    name: str
    issuer_name: str
    issuer_inn: str
    sector: str
    share_class: str
    listing_level: int | None
    boardid: str
    currency: str
    identity_status: str
    identity_source_url: str
    sector_crosscheck_status: str
    iis_eligible: bool
    iis_snapshot_at: str
    iis_temporal_status: str
    precheck_turnover_60_rub: float
    current_moex_match: bool


def build_iis_candidate_pool(
    *,
    tbank_universe_path: Path,
    allowlist_path: Path,
    as_of: date,
) -> tuple[list[dict[str, str]], dict[str, int]]:
    """Нормализовать два обезличенных read-only снимка в пул до ликвидности."""
    instruments = _read_csv(
        tbank_universe_path,
        {
            "ticker", "isin", "class_code", "name", "share_type", "sector",
            "currency", "for_iis_flag", "generated_at",
        },
    )
    allow_rows = _read_csv(
        allowlist_path,
        {
            "observed_at", "secid", "isin", "instrument_type", "currency",
            "api_trade_available", "buy_available",
        },
    )
    allow = {
        row["secid"].upper(): row
        for row in allow_rows
        if row["instrument_type"].casefold() == "share"
        and row["currency"].casefold() == "rub"
        and _is_true(row["api_trade_available"])
        and _is_true(row["buy_available"])
    }
    allowed_types = {"SHARE_TYPE_COMMON", "SHARE_TYPE_PREFERRED"}
    candidates = []
    isin_mismatches = 0
    for row in instruments:
        secid = row["ticker"].upper()
        if not (
            _is_true(row["for_iis_flag"])
            and row["class_code"].upper() == "TQBR"
            and row["currency"].casefold() == "rub"
            and row["share_type"].upper() in allowed_types
            and secid in allow
        ):
            continue
        current = allow[secid]
        metadata_isin = row["isin"].upper()
        allow_isin = current["isin"].upper()
        if metadata_isin and allow_isin and metadata_isin != allow_isin:
            isin_mismatches += 1
            continue
        observed_at = current["observed_at"]
        candidates.append(
            {
                "ticker": secid,
                "isin": metadata_isin or allow_isin,
                "name": row["name"],
                "share_type": row["share_type"].upper(),
                "sector_tbank_reference": row["sector"],
                "tbank_snapshot_at": observed_at,
                "iis_temporal_status": _temporal_status(observed_at, as_of),
                "metadata_generated_at": row["generated_at"],
                "allowlist_observed_at": observed_at,
                "sector_crosscheck_status": "not_checked",
                "eligibility_source": "tbank_live_read_only_allowlist",
            }
        )
    candidates.sort(key=lambda item: item["ticker"])
    counts = {
        "tbank_instruments": len(instruments),
        "current_buyable_shares": len(allow),
        "candidates": len(candidates),
        "isin_mismatches_excluded": isin_mismatches,
    }
    return candidates, counts


def load_universe(
    precheck_path: Path,
    issuer_map_path: Path,
    moex_securities_path: Path,
    *,
    as_of: date | None = None,
) -> tuple[list[UniverseSecurity], dict[str, int]]:
    """Загрузить прошедшие классы и механически оставить один SECID на эмитента."""
    precheck = _read_csv(
        precheck_path,
        {
            "ticker", "isin", "name", "share_type", "sector_tbank_reference",
            "median_turnover_rub", "research_universe_precheck_pass",
            "tbank_snapshot_at", "iis_temporal_status",
        },
    )
    identities = {
        row["secid"].upper(): row
        for row in _read_csv(
            issuer_map_path,
            {
                "secid", "isin", "emitent_id", "emitent_title", "emitent_inn",
                "identity_status", "source_url",
            },
        )
    }
    current = {
        row["SECID"].upper(): row
        for row in _read_csv(
            moex_securities_path,
            {"SECID", "ISIN", "LISTLEVEL", "CURRENCYID", "SECTYPE"},
        )
        if row["SECTYPE"] in {"1", "2"} and row["CURRENCYID"] in {"RUB", "SUR"}
    }

    candidates: list[UniverseSecurity] = []
    unresolved = 0
    for row in precheck:
        if row["research_universe_precheck_pass"].casefold() != "true":
            continue
        secid = row["ticker"].upper()
        identity = identities.get(secid, {})
        identity_status = identity.get("identity_status") or "missing"
        emitent_id = identity.get("emitent_id", "")
        if identity_status != "matched" or not emitent_id:
            issuer_id = f"unresolved:{secid}"
            unresolved += 1
        else:
            issuer_id = emitent_id
        security = current.get(secid)
        candidates.append(
            UniverseSecurity(
                issuer_id=issuer_id,
                secid=secid,
                isin=(identity.get("isin") or row.get("isin") or "").upper(),
                name=row["name"],
                issuer_name=identity.get("emitent_title") or row["name"],
                issuer_inn=identity.get("emitent_inn", ""),
                sector=row["sector_tbank_reference"] or "unclassified",
                share_class=row["share_type"],
                listing_level=_optional_int((security or {}).get("LISTLEVEL")),
                boardid="TQBR",
                currency="RUB",
                identity_status=identity_status,
                identity_source_url=identity.get("source_url", ""),
                sector_crosscheck_status="not_checked",
                iis_eligible=True,
                iis_snapshot_at=row["tbank_snapshot_at"],
                iis_temporal_status=(
                    _temporal_status(row["tbank_snapshot_at"], as_of)
                    if as_of else row["iis_temporal_status"]
                ),
                precheck_turnover_60_rub=_number(
                    row["median_turnover_rub"], "median_turnover_rub"
                ),
                current_moex_match=security is not None,
            )
        )

    by_issuer: dict[str, list[UniverseSecurity]] = defaultdict(list)
    for item in candidates:
        by_issuer[item.issuer_id].append(item)
    selected = [
        sorted(
            classes,
            key=lambda item: (-item.precheck_turnover_60_rub, item.secid),
        )[0]
        for classes in by_issuer.values()
    ]
    selected.sort(key=lambda item: item.secid)
    counts = {
        "precheck_rows": len(precheck),
        "passing_share_classes": len(candidates),
        "selected_issuers": len(selected),
        "deduplicated_share_classes": len(candidates) - len(selected),
        "unresolved_identities": unresolved,
        "missing_current_moex": sum(not item.current_moex_match for item in selected),
    }
    return selected, counts


def load_candidate_secids(precheck_path: Path) -> list[str]:
    """Все уже отфильтрованные по типу/TQBR/RUB/ИИС классы, до ликвидности."""
    rows = _read_csv(precheck_path, {"ticker"})
    return sorted({row["ticker"].upper() for row in rows if row["ticker"]})


def recompute_precheck(
    *,
    base_precheck_path: Path,
    current_securities: list[dict[str, Any]],
    bars: list[MarketBar],
    benchmark: list[IndexPoint],
    as_of: date,
) -> list[dict[str, str]]:
    """Пересчитать текущие MOEX/ликвидностные ворота для исходного IIS-пула."""
    rows = _read_csv(
        base_precheck_path,
        {"ticker", "tbank_snapshot_at", "iis_temporal_status"},
    )
    current = {
        str(row.get("SECID", "")).upper()
        for row in current_securities
        if str(row.get("SECTYPE", "")) in {"1", "2"}
        and str(row.get("CURRENCYID", "")) in {"RUB", "SUR"}
    }
    calendar = sorted(
        {
            row.trade_date
            for row in benchmark
            if row.secid == "MCFTR" and row.trade_date <= as_of
        }
    )
    session_dates = set(calendar[-60:])
    values: dict[str, list[float]] = defaultdict(list)
    observed_dates: dict[str, set[date]] = defaultdict(set)
    for bar in bars:
        if bar.trade_date not in session_dates:
            continue
        if bar.close is not None and bar.close > 0:
            observed_dates[bar.secid].add(bar.trade_date)
        if bar.value is not None and bar.value >= 0:
            values[bar.secid].append(bar.value)

    output: list[dict[str, str]] = []
    for source in rows:
        row = dict(source)
        secid = row["ticker"].upper()
        observations = len(observed_dates.get(secid, set()))
        median = statistics.median(values[secid]) if values.get(secid) else 0.0
        moex_match = secid in current
        liquidity_pass = (
            observations >= MIN_SESSIONS_60
            and median >= MIN_MEDIAN_TURNOVER_RUB
        )
        passed = moex_match and liquidity_pass
        reasons = []
        if not moex_match:
            reasons.append("missing-current-moex")
        if observations < MIN_SESSIONS_60:
            reasons.append("insufficient-sessions")
        if median < MIN_MEDIAN_TURNOVER_RUB:
            reasons.append("below-turnover-threshold")
        row.update(
            {
                "signal_as_of": as_of.isoformat(),
                "market_data_through": calendar[-1].isoformat() if calendar else "",
                "iis_temporal_status": _temporal_status(
                    row["tbank_snapshot_at"], as_of
                ),
                "sessions_window": "60",
                "observations": str(observations),
                "median_turnover_rub": f"{median:.2f}",
                "min_observations": str(MIN_SESSIONS_60),
                "min_median_turnover_rub": f"{MIN_MEDIAN_TURNOVER_RUB:.2f}",
                "moex_current_match": str(moex_match).lower(),
                "liquidity_pass": str(liquidity_pass).lower(),
                "research_universe_precheck_pass": str(passed).lower(),
                "status_note": (
                    "passes-current-IIS-reference-and-liquidity-precheck"
                    if passed else "|".join(reasons)
                ),
            }
        )
        output.append(row)
    output.sort(
        key=lambda row: (
            row["research_universe_precheck_pass"] != "true",
            -float(row["median_turnover_rub"]),
            row["ticker"],
        )
    )
    return output


def write_precheck(path: Path, rows: list[dict[str, str]]) -> Path:
    if not rows:
        raise MarketProfileContractError("Нельзя записать пустой precheck")
    columns: list[str] = []
    for row in rows:
        for key in row:
            if key not in columns:
                columns.append(key)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    return path


def calculate_market_profile(
    security: UniverseSecurity,
    bars: Iterable[MarketBar],
    calendar_dates: Iterable[date],
    as_of: date,
) -> dict[str, Any]:
    rows = sorted(
        (row for row in bars if row.secid == security.secid and row.trade_date <= as_of),
        key=lambda row: row.trade_date,
    )
    prices = [row for row in rows if row.close is not None and row.close > 0]
    calendar = sorted({item for item in calendar_dates if item <= as_of})
    calendar_20 = set(calendar[-20:])
    calendar_60 = set(calendar[-60:])
    sessions_20 = len({row.trade_date for row in prices if row.trade_date in calendar_20})
    sessions_60 = len({row.trade_date for row in prices if row.trade_date in calendar_60})
    expected_60 = min(60, len(calendar))
    coverage_60 = sessions_60 / expected_60 if expected_60 else None
    values_20 = [
        row.value for row in rows
        if row.trade_date in calendar_20 and row.value is not None and row.value >= 0
    ]
    values_60 = [
        row.value for row in rows
        if row.trade_date in calendar_60 and row.value is not None and row.value >= 0
    ]

    notes: list[str] = []
    if not prices:
        return {
            "status": "unavailable",
            "price_as_of": None,
            "latest_close": None,
            "currency": security.currency,
            "history_start": rows[0].trade_date.isoformat() if rows else None,
            "history_end": rows[-1].trade_date.isoformat() if rows else None,
            "sessions_20": sessions_20,
            "sessions_60": sessions_60,
            "sessions_60_required": MIN_SESSIONS_60,
            "coverage_60_pct": _pct(coverage_60),
            "turnover_median_20_rub": _money_median(values_20),
            "turnover_median_60_rub": _money_median(values_60),
            "price_change_1y_pct": None,
            "price_change_3y_pct": None,
            "volatility_1y_pct": None,
            "max_drawdown_1y_pct": None,
            "max_drawdown_3y_pct": None,
            "distance_to_52w_high_pct": None,
            "distance_from_52w_low_pct": None,
            "notes": ["Нет положительной цены закрытия не позже даты среза."],
        }

    latest = prices[-1]
    latest_calendar = calendar[-1] if calendar else None
    if latest_calendar and latest.trade_date < latest_calendar:
        notes.append(
            f"Последняя цена {latest.trade_date.isoformat()}, календарь MCFTR "
            f"заканчивается {latest_calendar.isoformat()}."
        )
    if expected_60 < 60:
        notes.append("Календарь содержит менее 60 сессий.")
    if sessions_60 < MIN_SESSIONS_60:
        notes.append(f"Только {sessions_60} из 60 требуемых сессий.")
    if not security.current_moex_match:
        notes.append("SECID отсутствует в текущем справочнике TQBR.")

    one_year = _covered_window(prices, latest.trade_date, 365, 14)
    three_year = _covered_window(prices, latest.trade_date, 365 * 3, 30)
    if one_year is None:
        notes.append("Недостаточно истории для годовых показателей.")
    if three_year is None:
        notes.append("Недостаточно истории для трёхлетних показателей.")

    volatility = None
    if one_year is not None and len(one_year) >= 181:
        log_returns = [
            math.log(current.close / previous.close)
            for previous, current in zip(one_year, one_year[1:])
            if previous.close and current.close and previous.close > 0 and current.close > 0
        ]
        if len(log_returns) >= 180:
            volatility = statistics.stdev(log_returns) * math.sqrt(252)

    market_status = (
        "computed"
        if security.current_moex_match
        and (latest_calendar is None or latest.trade_date >= latest_calendar)
        and sessions_60 >= MIN_SESSIONS_60
        else "partial"
    )
    return {
        "status": market_status,
        "price_as_of": latest.trade_date.isoformat(),
        "latest_close": _round(latest.close),
        "currency": security.currency,
        "history_start": prices[0].trade_date.isoformat(),
        "history_end": latest.trade_date.isoformat(),
        "sessions_20": sessions_20,
        "sessions_60": sessions_60,
        "sessions_60_required": MIN_SESSIONS_60,
        "coverage_60_pct": _pct(coverage_60),
        "turnover_median_20_rub": _money_median(values_20),
        "turnover_median_60_rub": _money_median(values_60),
        "price_change_1y_pct": _price_change(one_year),
        "price_change_3y_pct": _price_change(three_year),
        "volatility_1y_pct": _pct(volatility),
        "max_drawdown_1y_pct": _pct(_max_drawdown(one_year)),
        "max_drawdown_3y_pct": _pct(_max_drawdown(three_year)),
        "distance_to_52w_high_pct": _pct(_distance_to_high(one_year)),
        "distance_from_52w_low_pct": _pct(_distance_from_low(one_year)),
        "notes": notes,
    }


def build_market_snapshot(
    *,
    as_of: date,
    universe: list[UniverseSecurity],
    universe_counts: dict[str, int],
    bars: list[MarketBar],
    benchmark: list[IndexPoint],
    methodology_path: Path,
    input_paths: dict[str, Path],
    quality_snapshot_path: Path | None = None,
    generated_at: datetime | None = None,
) -> dict[str, Any]:
    quality_rows, quality_note = _load_quality_rows(quality_snapshot_path, as_of=as_of)
    bars_by_secid: dict[str, list[MarketBar]] = defaultdict(list)
    for row in bars:
        bars_by_secid[row.secid].append(row)
    calendar_dates = [row.trade_date for row in benchmark if row.secid == "MCFTR"]

    rows = []
    for security in universe:
        market = calculate_market_profile(
            security, bars_by_secid.get(security.secid, []), calendar_dates, as_of
        )
        quality = _quality_block(security, quality_rows.get(security.issuer_id))
        rows.append(
            {
                "issuer_id": security.issuer_id,
                "secid": security.secid,
                "isin": security.isin,
                "name": security.name,
                "issuer_name": security.issuer_name,
                "issuer_inn": security.issuer_inn,
                "sector": security.sector,
                "sector_name": SECTOR_NAMES.get(security.sector, security.sector),
                "share_class": security.share_class,
                "listing_level": security.listing_level,
                "boardid": security.boardid,
                "identity_status": security.identity_status,
                "identity_source_url": security.identity_source_url,
                "sector_crosscheck_status": security.sector_crosscheck_status,
                "iis": {
                    "eligible": security.iis_eligible,
                    "snapshot_at": security.iis_snapshot_at,
                    "temporal_status": security.iis_temporal_status,
                },
                "market": market,
                "quality": quality,
            }
        )
    rows.sort(
        key=lambda row: (
            row["sector"],
            -(row["market"]["turnover_median_60_rub"] or 0),
            row["secid"],
        )
    )

    sector_rows = []
    for sector in sorted({row["sector"] for row in rows}):
        selected = [row for row in rows if row["sector"] == sector]
        market_counts = Counter(row["market"]["status"] for row in selected)
        quality_counts = Counter(row["quality"]["status"] for row in selected)
        sector_rows.append(
            {
                "sector": sector,
                "name": SECTOR_NAMES.get(sector, sector),
                "issuers": len(selected),
                "market": dict(sorted(market_counts.items())),
                "quality": dict(sorted(quality_counts.items())),
                "ranking_formed": sum(
                    row["quality"]["status"] == "quality_computed" for row in selected
                ) >= 5,
            }
        )

    generated = generated_at or datetime.now(timezone.utc)
    if generated.tzinfo is None:
        raise MarketProfileContractError("generated_at должен содержать timezone")
    benchmark_rows = [
        row for row in benchmark if row.secid == "MCFTR" and row.trade_date <= as_of
    ]
    warnings = []
    if quality_note:
        warnings.append(quality_note)
    if any(row["sector_crosscheck_status"] == "not_checked" for row in rows):
        warnings.append(
            "Сектора взяты из read-only справочника Т-Банка как навигационные "
            "метки и пока не прошли внешний кросс-чек."
        )
    if any(row["iis"]["temporal_status"] == "checked_after_signal_date" for row in rows):
        warnings.append(
            "Часть флагов ИИС проверена после as_of и не доказывает историческую доступность."
        )
    if any(row["market"]["status"] != "computed" for row in rows):
        warnings.append("Часть рыночных профилей рассчитана неполностью; см. market.notes.")
    warnings.append(
        "Изменения цены рассчитаны без дивидендов и не сравниваются с MCFTR."
    )

    sources = [_file_source(name, path) for name, path in sorted(input_paths.items())]
    if quality_snapshot_path:
        sources.append(_file_source("quality_snapshot", quality_snapshot_path))
    return {
        "schema_version": SCHEMA_VERSION,
        "methodology_version": METHODOLOGY_VERSION,
        "methodology_sha256": _sha256(methodology_path),
        "as_of": as_of.isoformat(),
        "generated_at": generated.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
        "purpose": "read_only_market_profile_with_separate_fundamental_quality",
        "universe": {
            **universe_counts,
            "selection_rule": "highest_60_session_median_turnover_per_issuer",
            "min_sessions_60": MIN_SESSIONS_60,
            "min_median_turnover_rub": MIN_MEDIAN_TURNOVER_RUB,
        },
        "sectors": sector_rows,
        "rows": rows,
        "benchmark": {
            "secid": "MCFTR",
            "points": len(benchmark_rows),
            "history_start": (
                min(row.trade_date for row in benchmark_rows).isoformat()
                if benchmark_rows else None
            ),
            "history_end": (
                max(row.trade_date for row in benchmark_rows).isoformat()
                if benchmark_rows else None
            ),
            "role": "trading_calendar_and_future_total_return_backtest_only",
        },
        "sources": sources,
        "warnings": warnings,
    }


def write_market_snapshot(path: Path, payload: dict[str, Any]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=False) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)
    return path


def write_coverage_report(path: Path, payload: dict[str, Any]) -> Path:
    market = Counter(row["market"]["status"] for row in payload["rows"])
    quality = Counter(row["quality"]["status"] for row in payload["rows"])
    metrics = [
        "latest_close", "turnover_median_60_rub", "price_change_1y_pct",
        "price_change_3y_pct", "volatility_1y_pct", "max_drawdown_1y_pct",
    ]
    lines = [
        "# Покрытие автоматического рыночного профиля v0.3",
        "",
        f"Срез: `{payload['as_of']}`. Схема: `{payload['schema_version']}`.",
        "",
        "## Вселенная",
        "",
        f"- Прошедших классов акций: {payload['universe']['passing_share_classes']}.",
        f"- Эмитентов после дедупликации: {len(payload['rows'])}.",
        f"- Неразрешённых идентичностей: {payload['universe']['unresolved_identities']}.",
        "",
        "## Рыночный статус",
        "",
    ]
    for status, count in sorted(market.items()):
        lines.append(f"- `{status}`: {count}.")
    lines.extend(["", "## Фундаментальный статус", ""])
    for status, count in sorted(quality.items()):
        lines.append(f"- `{status}`: {count}.")
    lines.extend(["", "## Покрытие полей", ""])
    for metric in metrics:
        count = sum(row["market"].get(metric) is not None for row in payload["rows"])
        lines.append(f"- `{metric}`: {count} из {len(payload['rows'])}.")
    lines.extend(["", "## Сектора", ""])
    lines.append("| Сектор | Эмитентов | Рыночный профиль computed | Quality computed |")
    lines.append("|---|---:|---:|---:|")
    for sector in payload["sectors"]:
        lines.append(
            f"| {sector['name']} | {sector['issuers']} | "
            f"{sector['market'].get('computed', 0)} | "
            f"{sector['quality'].get('quality_computed', 0)} |"
        )
    lines.extend(["", "## Ограничения снимка", ""])
    lines.extend(f"- {warning}" for warning in payload["warnings"])
    lines.extend(
        [
            "",
            "Следующая очередь официальных документов формируется после этого отчёта; "
            "массовое скачивание PDF заранее не требуется.",
            "",
        ]
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text("\n".join(lines), encoding="utf-8")
    temporary.replace(path)
    return path


def _quality_block(
    security: UniverseSecurity, source: dict[str, Any] | None
) -> dict[str, Any]:
    if security.sector == "financial":
        return {
            "status": "financial_model_pending",
            "score": None,
            "rank": None,
            "sector_candidate": False,
            "admissibility_status": "financial_methodology_not_defined",
            "reasons": ["Для финансового сектора требуется отдельная методика."],
            "missing_required_metrics": [],
            "missing_fcf_years": [],
            "crosscheck": {"matched": 0, "mismatched": 0, "not_checked": 0},
        }
    if source is None:
        return {
            "status": "insufficient_data",
            "score": None,
            "rank": None,
            "sector_candidate": False,
            "admissibility_status": "fundamental_collection_not_started",
            "reasons": ["Фундаментальный доказательный пакет ещё не собран."],
            "missing_required_metrics": [],
            "missing_fcf_years": [],
            "crosscheck": {"matched": 0, "mismatched": 0, "not_checked": 0},
        }

    source_status = source.get("status")
    admissibility = source.get("admissibility_status", "")
    score = source.get("score")
    rank = source.get("rank")
    if source_status == "blocked":
        status = "blocked"
    elif score is not None and rank is not None:
        status = "quality_computed"
    elif admissibility == "incomplete_required_metrics":
        status = "fundamentals_partial"
    else:
        status = "insufficient_data"
    return {
        "status": status,
        "score": score if status == "quality_computed" else None,
        "rank": rank if status == "quality_computed" else None,
        "sector_candidate": bool(source.get("sector_candidate", False)),
        "admissibility_status": admissibility,
        "reasons": list(source.get("reasons") or []),
        "missing_required_metrics": list(source.get("missing_required_metrics") or []),
        "missing_fcf_years": list(source.get("missing_fcf_years") or []),
        "crosscheck": source.get("crosscheck") or {
            "matched": 0, "mismatched": 0, "not_checked": 0
        },
    }


def _load_quality_rows(
    path: Path | None, *, as_of: date
) -> tuple[dict[str, dict[str, Any]], str | None]:
    """Read the existing PC handoff, preserving its own date and methodology.

    This is transport validation, not a new audit of financial statements.
    A future multi-sector quality format requires an explicit adapter/version.
    """
    if path is None:
        return {}, None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise MarketProfileContractError(f"Не удалось прочитать quality snapshot: {exc}") from exc
    if not isinstance(payload, dict):
        raise MarketProfileContractError("quality snapshot должен быть JSON-объектом")
    if (
        payload.get("schema_version") != "materials-scoring-snapshot.v0.2"
        or payload.get("methodology_version") != "0.2"
    ):
        raise MarketProfileContractError("Неизвестная версия quality snapshot/методологии")
    digest = payload.get("methodology_sha256")
    if not isinstance(digest, str) or len(digest) != 64 or any(
        char not in "0123456789ABCDEF" for char in digest
    ):
        raise MarketProfileContractError("quality snapshot: нужен methodology_sha256")
    stamp = payload.get("as_of")
    try:
        if not isinstance(stamp, str) or "T" not in stamp or not stamp.endswith("Z"):
            raise ValueError("UTC Z required")
        quality_timestamp = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
        if quality_timestamp.utcoffset() != timedelta(0):
            raise ValueError("UTC required")
        quality_date = quality_timestamp.date()
    except ValueError as exc:
        raise MarketProfileContractError("quality snapshot: as_of должен быть UTC с Z") from exc
    if quality_date > as_of:
        raise MarketProfileContractError("quality snapshot новее даты рыночного среза")
    gate = payload.get("sector_gate")
    if not isinstance(gate, dict) or gate.get("sector") != "materials":
        raise MarketProfileContractError("quality snapshot: нужен sector_gate Materials v0.2")
    rows = payload.get("rows")
    if not isinstance(rows, list):
        raise MarketProfileContractError("quality snapshot не содержит rows[]")
    result = {}
    note = (
        f"Фундаментальный снимок: {stamp}; методология {payload['methodology_version']}; "
        f"SHA-256 методологии {digest}. Рыночное обновление не меняет дату фундаментала."
    )
    for row in rows:
        if not isinstance(row, dict):
            raise MarketProfileContractError("quality snapshot: строка должна быть объектом")
        issuer_id = row.get("issuer_id")
        if not isinstance(issuer_id, str) or not issuer_id or issuer_id in result:
            raise MarketProfileContractError(
                "quality snapshot содержит пустой или повторный issuer_id"
            )
        if row.get("sector") != "materials" or row.get("as_of") != stamp:
            raise MarketProfileContractError("quality snapshot: сектор/дата строки не совпадают с корнем")
        status = row.get("status")
        score, rank = row.get("score"), row.get("rank")
        if status not in {"computed", "blocked", "insufficient_data"}:
            raise MarketProfileContractError("quality snapshot: неизвестный status строки")
        if status != "computed" and (score is not None or rank is not None):
            raise MarketProfileContractError("quality snapshot: до computed score/rank должны быть null")
        if status == "computed" and not (
            type(score) in {int, float} and math.isfinite(score) and 0 <= score <= 100
            and type(rank) is int and rank >= 1
            and gate.get("status") == "formed"
            and type(gate.get("valid_issuers")) is int and gate["valid_issuers"] >= 5
        ):
            raise MarketProfileContractError("quality snapshot: балл/рейтинг не подтверждены sector_gate")
        reasons = row.get("reasons")
        if not isinstance(reasons, list) or not all(isinstance(item, str) for item in reasons):
            raise MarketProfileContractError("quality snapshot: reasons должен быть списком строк")
        result[issuer_id] = {**row, "reasons": [*reasons, note]}
    return result, note


def _covered_window(
    prices: list[MarketBar], latest_date: date, days: int, max_gap_days: int
) -> list[MarketBar] | None:
    target = latest_date - timedelta(days=days)
    window = [row for row in prices if row.trade_date >= target]
    if not window or window[0].trade_date > target + timedelta(days=max_gap_days):
        return None
    return window


def _price_change(window: list[MarketBar] | None) -> float | None:
    if not window or len(window) < 2 or not window[0].close or not window[-1].close:
        return None
    return _pct(window[-1].close / window[0].close - 1)


def _max_drawdown(window: list[MarketBar] | None) -> float | None:
    if not window:
        return None
    peak = -math.inf
    worst = 0.0
    for row in window:
        if row.close is None or row.close <= 0:
            continue
        peak = max(peak, row.close)
        worst = min(worst, row.close / peak - 1)
    return worst if peak > 0 else None


def _distance_to_high(window: list[MarketBar] | None) -> float | None:
    closes = [row.close for row in window or [] if row.close is not None and row.close > 0]
    return closes[-1] / max(closes) - 1 if closes else None


def _distance_from_low(window: list[MarketBar] | None) -> float | None:
    closes = [row.close for row in window or [] if row.close is not None and row.close > 0]
    return closes[-1] / min(closes) - 1 if closes else None


def _money_median(values: list[float]) -> float | None:
    return round(statistics.median(values), 2) if values else None


def _round(value: float | None) -> float | None:
    return round(value, 8) if value is not None else None


def _pct(value: float | None) -> float | None:
    return round(value * 100, 6) if value is not None else None


def _read_csv(path: Path, required: set[str]) -> list[dict[str, str]]:
    if not path.exists():
        raise MarketProfileContractError(f"Файл не найден: {path}")
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        actual = set(reader.fieldnames or [])
        missing = required - actual
        if missing:
            raise MarketProfileContractError(
                f"{path}: отсутствуют столбцы {', '.join(sorted(missing))}"
            )
        return [
            {key: (value or "").strip() for key, value in row.items()}
            for row in reader
        ]


def _number(value: str, field: str) -> float:
    try:
        return float(value.replace(" ", "").replace(",", "."))
    except ValueError as exc:
        raise MarketProfileContractError(f"{field}: ожидалось число, получено {value!r}") from exc


def _is_true(value: str) -> bool:
    return value.strip().casefold() in {"1", "true", "yes", "да"}


def _optional_int(value: str | None) -> int | None:
    if not value:
        return None
    try:
        return int(value)
    except ValueError as exc:
        raise MarketProfileContractError(f"LISTLEVEL: ожидалось целое, получено {value!r}") from exc


def _temporal_status(timestamp: str, as_of: date | None) -> str:
    if as_of is None:
        return "snapshot_date_unknown"
    try:
        observed = datetime.fromisoformat(timestamp.replace("Z", "+00:00")).date()
    except ValueError:
        return "snapshot_date_unknown"
    if observed > as_of:
        return "checked_after_signal_date"
    if observed == as_of:
        return "checked_on_signal_date"
    return "checked_before_signal_date"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def _file_source(name: str, path: Path) -> dict[str, Any]:
    return {
        "name": name,
        "kind": "local_input",
        "file_name": path.name,
        "sha256": _sha256(path),
    }
